                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 // to calculate volume of cone
import java.util.Scanner;
class Cone
{
   public static void main(String ]arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter edge of cone");
       double a=sc.nextDouble();
       double volume=a*a*a;
       System.out.println("volume of cone="+ volume);
   }
}