/*cap in java to copy the contents of one file to Another */
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyCharByChar {

    public static void main(String arr[]) {
        try{
            FileInputStream f1=new FileInputStream(arr[0]);
            FileOutputStream f2=new FileOutputStream(arr[1]);
            int ch;
            while (true) {
                ch=f1.read();
                if(ch==-1){
                    break;
                }
                f2.write((byte) ch);
            }
            f1.close();
            f2.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}