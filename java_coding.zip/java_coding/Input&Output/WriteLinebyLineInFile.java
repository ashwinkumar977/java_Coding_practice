import java.io.*;
public class WriteLinebyLineInFile {
    public static void main(String args[]) {
        try {
            BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
            PrintWriter p=new PrintWriter(new FileWriter(args[0]));
            System.out.println("Enter data to Write and input end to Stop");
            while (true) {
                String msg=b.readLine();
                if(msg.equalsIgnoreCase("end")){
                    break;
                }
                p.println(msg);
            }
            p.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
