/*Cap in java to display Contents of two File one by one in a
 * sequence without using SequenceInputStream
 */
import java.io.*;
public class EgSequenceInputStream {
    public static void main(String[] args) {
        try {
            FileInputStream f1=new FileInputStream(args[0]);
            FileInputStream f2=new FileInputStream(args[1]);
            int ch;
            while (true) {
                ch=f1.read();
                if(ch==-1){
                    break;
                }
                System.out.print((char)ch);
            }
            while (true) {
                ch=f2.read();
                if(ch==-1){
                    break;
                }
                System.out.print((char)ch);
            }
            f1.close();
            f2.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
