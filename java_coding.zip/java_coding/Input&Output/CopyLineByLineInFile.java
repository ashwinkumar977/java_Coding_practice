import java.io.*;
public class CopyLineByLineInFile {
    public static void main(String args[]) {
        try {
            BufferedReader b=new BufferedReader(new FileReader(args[0]));
            PrintWriter p=new PrintWriter(new FileWriter(args[1],true));
            while (true) {
                String msg=b.readLine();
                if(msg.equalsIgnoreCase("end")){
                    break;
                }
                p.println(msg);
            }
            p.close();
            b.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
