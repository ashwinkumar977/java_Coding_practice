import java.io.FileInputStream;

public class DisplayBytebyByte {
    public static void main(String args[]) {
        try {
            FileInputStream fl=new FileInputStream(args[0]);
            int b;
            while (true) {
                b=fl.read();
                if(b==-1){
                    break;
                }
                else{
                    System.out.print((char)b);
                }
            }
            fl.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
