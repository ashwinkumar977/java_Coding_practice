import java.io.FileInputStream;

public class DisplayContents {
    public static void main(String arr[]) {
        try {
            FileInputStream f1=new FileInputStream(arr[0]);
            int s=f1.available();
            byte b[]=new byte[s];
            f1.read(b);
            String s1=new String(b);
            System.out.println(s1);
            f1.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
