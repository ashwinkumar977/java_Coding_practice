import java.io.File;

public class DIR {
    public static void main(String[] args) {
        try {
            File f;
            if(args.length==0){
                f=new File(":");
            }
            String s[]=f.list();
            for(int i=0;i<s.length;i++){
                File f1=new File(f,s[i]);
                if(f1.isFile()){
                    System.out.println(s[i]+"\t<<file>>");
                }
                else{
                    System.out.println(s[i]+"\t<<dir>>");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
