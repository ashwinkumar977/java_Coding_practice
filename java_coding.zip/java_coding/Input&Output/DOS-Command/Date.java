import java.util.Calendar;

public class Date {
    public static void main(String[] args) {
        String s[]={"SUN","MON","TUE","WED","THR","FRI","SAT"};
        Calendar c=Calendar.getInstance();
        int d=c.get(Calendar.DATE);
        int m=c.get(Calendar.MONTH)+1;
        int y=c.get(Calendar.YEAR);
        String dw=s[c.get(Calendar.DAY_OF_WEEK)-1];
        System.out.println("The current System Date is.. "+dw+" "+d+"_"+m+"_"+y);   
    }
}
