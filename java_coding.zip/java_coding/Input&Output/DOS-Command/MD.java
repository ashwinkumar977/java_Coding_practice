import java.io.File;

public class MD {
    public static void main(String[] args) {
        try {
            File f=new File(args[0]);
            if(f.exists()){
                System.out.println(args[0]+"Directory is Already Exists");
            }
            else{
                if(f.mkdir()){
                    System.out.println(args[0]+"Directory is Successfully Created");
                }
                else{
                    System.out.println("Directory Can't be Created");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
