import java.util.*;
public class Time {

    public static void main(String[] args) {
        Calendar c=Calendar.getInstance();
        int h=c.get(Calendar.HOUR);
        int m=c.get(Calendar.MINUTE);
        int s=c.get(Calendar.SECOND);
        System.out.println("The Current System time is "+h+":"+m+":"+s);
    }
}