import java.io.*;
public class EgSequenceInputStreamWith  {
    public static void main(String[] args) {
        try {
            FileInputStream f1=new FileInputStream(args[0]);
            FileInputStream f2=new FileInputStream(args[1]);
            int ch;
            SequenceInputStream s=new SequenceInputStream(f1,f2);
            while (true) {
                ch=s.read();
                if(ch==-1){
                    break;
                }
                System.out.print((char)ch);
            }
            f1.close();
            f2.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
