/*cap in java to read a block of byte from one file and
 *  write that block of bytes to another file
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Copy {
    public static void main(String arr[]) {
        try {
            FileInputStream f1=new FileInputStream(arr[0]);
            FileOutputStream f2=new FileOutputStream(arr[1]);
            int s=f1.available();
            byte b[]=new byte[s];
            f1.read(b);
            f2.write(b);
            f1.close();
            f2.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
