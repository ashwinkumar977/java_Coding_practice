/* cap in java to calculate area of circle where radius is 
 inputed thrpugh a command line argument
 */
public class Circle {
    public static void main(String[] args) {
        double r=Double.parseDouble(args[0]);
        double area=3.141*r*r;
        System.out.println("area of circle="+area);
    }
}
