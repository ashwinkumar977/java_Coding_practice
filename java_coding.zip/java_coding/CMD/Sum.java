/* cap in java for addition of two number where both number
 are inputed through a commond line argument
 */
public class Sum {
    public static void main(String[] args) {
        double a=Double.parseDouble(args[0]);
        double b=Double.parseDouble(args[1]);
        double s=a+b;
        System.out.println("sum of two number="+s);
    }
}