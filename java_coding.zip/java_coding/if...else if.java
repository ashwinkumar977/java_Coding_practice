import java.util.Scanner;
class ifelseif
{
    public static void main(String[] args)
     {
        Scanner sc = new Scanner(System.in);
        int num; String st;
        System.out.println("enter the number");
        num=sc.nextInt();
        if (num > 0 )
            st="positive";
        else if (num < 0)
            st="negative";
        else
            st="zero";
        System.out.println(st);    
        sc.close();
     }
}
