/*
 *     problem4
 *     abcde
 *      abcd
 *       abc
 *        ab
 *         a
 */
public class Problem4 {
    public static void main(String[] args) {
        for(int i=101;i>=97;i--){
            for(int j=101;j>i;j--){
                System.out.print(' ');
            }
            for(int j=97;j<=i;j++){
                System.out.print((char)j);
            }
            System.out.println();
        }
    }
    
}