class StringDemo {
    public static void main(String[] args) {
        char a[]={'A','B','C','D','E'};
        byte b[]={65,66,67,68,69};
        String s1=new String(a);
        String s2=new String(b);
        String s3=new String(a,2,3);
        String s4=new String(b,1,3);
        String s5=new String("ABCDE");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
        System.out.println(s5);
        System.out.println(s1==s2);
        System.out.println(s2==s3);
        System.out.println(s3==s4);
        System.out.println(s1==s5);

    }
}