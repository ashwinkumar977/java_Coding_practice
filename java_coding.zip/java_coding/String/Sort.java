import java.util.Scanner;

public class Sort {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("input String");
        String s=sc.next();
        
        sc.close();
    }
    
}
