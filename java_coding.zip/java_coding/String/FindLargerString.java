import java.util.Scanner;

public class FindLargerString {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("input 1st String");
        String s1=sc.next();
        System.out.println("input 2nd String");
        String s2=sc.next();
        int c=(s1.compareTo(s2));
        if(c>0){
            System.out.println(s1+" is larger String");
        }
        else{
            System.out.println(s2+" is larger String");
        }
        sc.close();
    }
}
