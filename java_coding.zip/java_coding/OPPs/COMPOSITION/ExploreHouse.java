class Room{
    int nd,nw,area;
    public Room(int a,int b,int c){
        nd=a;
        nw=b;
        area=c;
    }
    void display(){
        System.out.println("number of doors="+nd);
        System.out.println("number of windows="+nw);
        System.out.println("total area of room="+area);
    }
}
class House{
    int area;
    Room bRoom,dRoom;
    public House(){
        area=1000;
        bRoom=new Room(1, 2, 130);
        dRoom=new Room(2, 3, 240);
    }
    void show(){
        System.out.println("Area of house="+area);
        System.out.println("it has bedroom with given details");
        bRoom.display();
        System.out.println("it has dinning room with given details");
        dRoom.display();
    }
}
/**
 * ExploreHouse
 */
public class ExploreHouse {
    public static void main(String[] args) {
        House h=new House();
        h.show();
    }
}