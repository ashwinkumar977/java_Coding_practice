/*cap in java to calculate volume of cone by using feature of abstraction */
class Cone{
    public double r,h;
    public Cone(double x, double y){
        r=x;
        h=y;
    }
    public void display(){
        System.out.println("radius of cone="+r);
        System.out.println("height of cone ="+h);
    }
    public double volume(){
        return (1*3.141*r*r*h)/3;
    }
}
public class Abstraction {
    public static void main(String[] args) {
        Cone c=new Cone(5.8, 7.34);
        c.display();
        System.out.println("volume of cone ="+c.volume());
    }
    
}
