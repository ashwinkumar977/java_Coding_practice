interface One{
    void display1();
}
interface Two{
    void display2();
}
class MoreInterfaceInSingleClass implements One,Two {
    public void display1(){
        System.out.println("it is of interface one");
    }
    public void display2(){
        System.out.println("it is of interface two");
    }
    public static void main(String[] args) {
        MoreInterfaceInSingleClass moreinterface=new MoreInterfaceInSingleClass();
        moreinterface.display1();
        moreinterface.display2();
    }
}
