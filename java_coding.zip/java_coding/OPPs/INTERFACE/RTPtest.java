interface Showable{
    void show();
}
class Invoker{
    public static void invoke(Showable s){
        s.show();
    }
}
class One implements Showable{
    int x;
    public One(int a){
        x=a;
    }
    public void show(){
        System.out.println("x="+x);
    }
}
class Two implements Showable{
    String s;
    public Two(String  s1){
        s=s1;
    }
    public void show(){
        System.out.println("String="+s);
    }
}
public class RTPtest {
    public static void main(String[] args) {
        One o=new One(8);
        Invoker.invoke(o);
        Two t=new Two("ashwin kumar");
        Invoker.invoke(t);
    }
}
