interface One{
    void display1();
    void display2();
}
class PartialImplimentInterface implements One {
    public void display1(){
        System.out.println("it is  of interface one");
    }
    public void display2(){
        System.out.println("it is of interface two");
    }
    public static void main(String[] args) {
        PartialImplimentInterface pti=new PartialImplimentInterface();
        pti.display1();
        pti.display2();
    }
}
