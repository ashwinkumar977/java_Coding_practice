interface One{
    abstract void show();
    final static double PI=3.141;
}
class First implements One{
    int x;
    First(int a){
        x=a;
    }
    public void show(){
        System.out.println("x="+x);
        System.out.println("PI="+PI);
    }
}
class Second implements One{
    String s;
    public Second(String x){
        s=x;
    }
    public void show(){
        System.out.println("String="+s);
        System.out.println("PI="+PI);
    }
}
public class InterfaceTest {
    public static void main(String[] args) {
        First f=new First(6);
        f.show();
        Second s=new Second("ashwin");
        s.show();
        System.out.println("PI="+One.PI);
    }
}