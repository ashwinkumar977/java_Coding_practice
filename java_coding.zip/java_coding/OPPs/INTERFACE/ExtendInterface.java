interface One{
    void display1();
}
interface Two extends One{
    void display2();
}
class ExtendInterface implements Two {
    public void display1(){
        System.out.println("It is of interface One");
    }
    public void display2(){
        System.out.println("It is of interface Two");
    }
    public static void main(String[] args) {
        ExtendInterface e=new ExtendInterface();
        e.display1();
        e.display2();
    }
}
