/* example of default constructor to calculate area and volume of cube */
import java.util.Scanner;
class Cube{
    double a;
    public Cube(){
        //a=6.0;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter sides of cube");
        a=sc.nextDouble();
        sc.close();
    }
    void display(){
        System.out.println("sides of cube="+a);
    }
    double volume(){
        return a*a*a;
    }
}
/**
 * DefaultConstructor
 */
public class TestCube {

    public static void main(String[] args) {
        Cube c=new Cube();
        c.display();
        System.out.println("volume of cube="+c.volume());
    }
}