/* cap to calculate area of a triangle by using argumented constructor */
class Triangle{
    double b,h;
    public Triangle(double x, double y){
        b=x;
        h=y;
    }
    void display(){
        System.out.println("base="+b);
        System.out.println("height="+h);
    }
    double area(){
        return (1*b*h)/2;
    }
}
public class TestTriangle {
    public static void main(String[] args) {
        Triangle t=new Triangle(3.68,7.93);
        t.display();System.out.println("area of a triangle="+t.area());
    }
    
}
