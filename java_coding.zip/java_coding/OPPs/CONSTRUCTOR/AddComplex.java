class Complex{
    int real,imagi;
    public Complex(int x,int y){
        real=x;
        imagi=y;
    }
    public Complex(){}
    void display(){
        System.out.println(real +"+i"+imagi);
    }
    void add(Complex c1,Complex c2){
        real=c1.real+c2.real;
        imagi=c1.imagi+c2.imagi;
    }
}
public class AddComplex {
    public static void main(String[] args) {
        Complex c1=new Complex(5,2);
        Complex c2=new Complex(4,7);
        Complex c3=new Complex();
        c3.add(c1,c2);
        System.out.println("first complex");
        c1.display();
        System.out.println("second complex");
        c2.display();
        System.out.println("after addition");
        c3.display();
    }
}
