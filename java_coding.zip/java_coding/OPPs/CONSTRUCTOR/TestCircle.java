/*example of argumented constructor to calculate area of a circle */

class Circle{
    double r;
    public Circle(double x){
        r=x;
    }
    void display(){
        System.out.println("radius of circle="+r);
    }
    double area(){
        return 3.141*r*r;
    }
}
public class TestCircle {
    public static void main(String[] args) {
      /*Scanner sc=new Scanner(System.in);
        System.out.println("enter radius of triangle");
        double r=sc.nextDouble();
        Circle c1=new Circle(r);
        c1.display();
        System.out.println("area of circle="+c1.area());
        sc.close();  */
        Circle c=new Circle(7);
        c.display();
        System.out.println("area of circle="+c.area());
    }
    
}
