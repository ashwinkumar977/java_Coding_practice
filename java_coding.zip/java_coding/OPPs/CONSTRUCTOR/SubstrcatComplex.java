class Complex{
    int real,imagi;
    public Complex(int x,int y){
        real=x;
        imagi=y;
    }
    public Complex(){}
    void display(){
        System.out.println(real +"+i"+imagi);
    }
    Complex substract(Complex c2){
        Complex c3=new Complex();
        c3.real=real-c2.real;
        c3.imagi=imagi-c2.imagi;
        return c3;
    }
}
public class SubstrcatComplex {
    public static void main(String[] args) {
        Complex c1=new Complex(5, 4);
        Complex c2=new Complex(4, 2);
        Complex c3=c1.substract(c2);
        System.out.println("first complex");
        c1.display();
        System.out.println("second complex");
        c2.display();
        System.out.println("after substraction");
        c3.display();
    }
}
