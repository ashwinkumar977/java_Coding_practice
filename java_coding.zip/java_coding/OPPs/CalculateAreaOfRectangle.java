/* cap in java to calculate area of rectangle by using the concept of class and object */
import java.util.Scanner;
class Rectangle{
    double l,b;
    void input(){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter length and breadth of rectangle");
        l=sc.nextDouble();
        b=sc.nextDouble();
        sc.close();
    }
    void display(){
        System.err.println("length="+l);
        System.out.println("breadth="+b);
    }
    double area(){
        return l*b;
    }
    double perimeter(){
        return 2*(l+b);
    }
}
/**
 * CalculateAreaOfRectangle
 */
public class CalculateAreaOfRectangle {
    public static void main(String[] args) {
        Rectangle r=new Rectangle();
        r.input();
        r.display();
        System.out.println("area of rectangle="+r.area());
        System.out.println("perimeter of rectangle="+r.perimeter());
    }
}