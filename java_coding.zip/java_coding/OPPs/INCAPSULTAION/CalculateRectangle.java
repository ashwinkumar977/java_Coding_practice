class Shape
{
    double l,b;
    public Shape(double x,double y){
        l=x;
        b=y;
    }
    public void display(){
        System.out.println("length="+l);
        System.out.println("breadth="+b);
    }
}
class Rectangle extends Shape{
    public Rectangle(double x,double y){
        super(x,y);  // l=x;
                     //  b=y;
    }
    double area(){
        return l*b;
    }
}
/**
 * CalculateRectangle
 */
public class CalculateRectangle {

    public static void main(String[] args) {
        Rectangle r=new Rectangle(5.8, 8.3);
        r.display();
        System.out.println("area of rectangle="+r.area());
    }
}