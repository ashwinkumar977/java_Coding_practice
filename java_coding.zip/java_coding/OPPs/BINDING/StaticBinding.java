class One{
    public void display(){
        System.out.println("it is class one");
    }
}
class Two extends One{
    public void display(){
        System.out.println("it is class two");
    }
}
class Three extends One{
    public void display(){
        System.out.println("it is class three");
    }
}

public class StaticBinding {
   public static void main (String arr[]){
       One o=new One();
       Two t=new Two();
       Three th=new Three();
       o.display();
       t.display();
       th.display();
   }
}