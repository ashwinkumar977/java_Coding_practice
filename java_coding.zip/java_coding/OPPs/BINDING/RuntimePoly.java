class A{}
class B{}
class C{}
public class RuntimePoly {
    public static void main(String[] args) {
        A a=new A();
        B b=new B();
        C c=new C();
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
}
