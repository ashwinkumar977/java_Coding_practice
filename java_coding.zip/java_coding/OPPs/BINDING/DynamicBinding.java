class One{
    public void display(){
        System.out.println("it is class one");
    }
}
class Two extends One{
    public void display(){
        System.out.println("it is class two");
    }
}
class Three extends One{
    public void display(){
        System.out.println("it is class three");
    }
}
class Four{
    public void show(One o){
        o.display();
    }

}
    
public class DynamicBinding {
    public static void main (String arr[]){
        One o=new One();
        Two t=new Two();
        Three th=new Three();
        o.display();
        t.display();
        th.display();
        
    }
}
