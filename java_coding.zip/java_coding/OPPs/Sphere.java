/* cap in java to calculate volume of sphere by using encapsulation */
class Sphere{
    private double r;
    public Sphere(double x){
        r=x;
    }
    void display(){
        System.out.println("radius of sphere="+r);
    }
    double volume(){
        return (4*3.141*r*r*r)/3;
    }
    public static void main(String[] args) {
        Sphere s=new Sphere(6.89);
        s.display();
        System.out.println("volume of sphere="+s.volume());
    }
}
