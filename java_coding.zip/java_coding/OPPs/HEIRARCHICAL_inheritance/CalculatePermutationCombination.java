/* example of heirarical inheritance */


class PermComb{  //super class
    int n,r;
    public PermComb(int x,int y){
        n=x;
        r=y;
    }
    void display(){
        System.out.println("n="+n);
        System.out.println("r="+r);
    }
    int fact(int n){
        int f=1;
        while (n>=1) {
            f=f*n;
            n--;
        }
        return f;
    }
}

//sub class permutation whose extends of super class of permcomb
class Permutation extends PermComb{
    public Permutation(int n,int r){
        super(n, r);
    }
    int  calculate(){
        return super.fact(n)/super.fact(n-r);
    }
}

//sub class combinatin whose extends of super class permcomb
class Combination extends PermComb{
    public Combination(int n,int r){
        super(n, r);
    }
    int  calculate(){
        return super.fact(n)/(super.fact(r)*super.fact(n-r));
    }
}

/**
 * CalculatePermutationCombination
 */
public class CalculatePermutationCombination {
    public static void main(String[] args) {
        Permutation p=new Permutation(5, 3);
        p.display();
        System.out.println("permutation="+p.calculate());
        Combination c=new Combination(6, 3);
        c.display();
        System.out.println("combination="+c.calculate());
    }
}