/*capin java to find square of input integer & floating point number by using overloading */
import java.util.Scanner;
public class SquareOfNumber {
    int square(int n){
        return n*n;
    }
    double square(double n){
        return n*n;
    }
    public static void main(String[] args) {
        SquareOfNumber s=new SquareOfNumber();
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any integer number");
        int n=sc.nextInt();
        System.out.println("square of input number="+s.square(n));
        System.out.println("***********************************************");
        System.out.println("enter any floating point number");
        double n1=sc.nextDouble();
        System.out.println("sqaure of input number="+s.square(n1));
        sc.close();
    }
}
