/* example of constructor overloading by varing type of argument */
public class Test {
    int x;
    public Test(int a){
        x=a;
    }
    public Test(double a){
        x=(int)a;
    }
    void display(){
        System.out.println("x="+x);
    }
    public static void main(String[] args) {
        Test t1=new Test(5);
        t1.display();
        Test t2=new Test(4.5);
        t2.display();
    }
}
