/* cap in java to calculate simple interest by using constructor overloading by varing number of argument */
class SimpleInterest {
    private double principal,rate,time;
    public SimpleInterest(double a,double b,double c){
        principal=a;
        rate=b;
        time=c;
    }
    public SimpleInterest(){
        principal=0.0;
        rate=0.0;
        time=0.0;
    }
    void display(){
        System.out.println("principal="+principal);
        System.out.println("rate="+rate);
        System.out.println("time="+time);
    }
    double si(){
        return principal*rate*time/100;
    }
}
/**
 * CalculateSimpleInterest
 */
public class CalculateSimpleInterest {
    public static void main(String[] args) {
        SimpleInterest s=new SimpleInterest();
        s.display();
        System.out.println("simple interest="+s.si());
        System.out.println("****************************************");
        SimpleInterest s1=new SimpleInterest(1000,10,3);
        s1.display();
        System.out.println("simple interest="+s1.si());
        
    }
}