/* cap in java to find largest number from two,three & four number by using overloading */
import java.util.Scanner;
/**
 * LargestNumber
 */
public class LargestNumber {

    int max(int a,int b){
        return a>b ? a :b;
    }
    int max(int a,int b,int c){
        return a>b ? a>c ?a:c :b>c ? b:c;
    }
    int max(int a,int b,int c,int d){
        return a>b ? a>c ? a>d ? a:d :c>d ?c:d :b>c ? b>d ? b:d :c>d? c:d;
    }
    public static void main(String[] args) {
        LargestNumber l=new LargestNumber();
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two integer number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        System.out.println("larger number b/w two number="+l.max(a, b));
        System.out.println("*********************************************************");
        System.out.println("enter any three integer number");
        int x=sc.nextInt();
        int y=sc.nextInt();
        int z=sc.nextInt();
        System.out.println("largest number among three number="+l.max(x, y, z));
        System.out.println("************************************************************");
        System.out.println("enter any four integer number ");
        int n1=sc.nextInt();
        int n2=sc.nextInt();
        int n3=sc.nextInt();
        int n4=sc.nextInt();
        System.out.println("largest number among four number="+l.max(n1, n2, n3, n4));
        sc.close();
    }
}