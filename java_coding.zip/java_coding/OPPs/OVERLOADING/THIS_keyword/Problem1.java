/* example of 1st purpose of this keyword */
/**
 * Problem1
 */
class Problem1 {

    int x,y;
    public Problem1(int x,int y){
        this.x=x;   //   x=x; wrong method        
        this.y=y;   //   y=y; wrong method     
    }
    void display(){
        System.out.println("x="+x);
        System.out.println("y="+y);
    }
    public static void main(String[] args) {
        Problem1 p1=new Problem1(5, 6);
        p1.display();
    }

}