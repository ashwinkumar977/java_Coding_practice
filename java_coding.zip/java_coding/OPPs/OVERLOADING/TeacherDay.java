import java.util.Scanner;
class TeacherDay {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter how many times");
        int n=sc.nextInt();
        for(int i=1;i<=n;i++){
            System.out.println("HAPPY");
            System.out.println("     TEACHER'S    ");
            System.out.println("            DAY    ");
        }
        sc.close();
    }

    
}
