/*capin java to find cube of input integer & floating point number by using overloading */
import java.util.Scanner;
public class CubeOfNumber {
    int cube(int n){
        return n*n*n;
    }
    double cube(double n){
        return n*n*n;
    }
    public static void main(String[] args) {
        CubeOfNumber c=new CubeOfNumber();
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any integer number");
        int n=sc.nextInt();
        System.out.println("square of input number="+c.cube(n));
        System.out.println("***********************************************");
        System.out.println("enter any floating point number");
        double n1=sc.nextDouble();
        System.out.println("sqaure of input number="+c.cube(n1));
        sc.close();
    }
}
