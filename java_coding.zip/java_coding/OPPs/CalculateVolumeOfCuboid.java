/* cap in java to calculate volume of cube */
import java.util.Scanner;
class Cuboid{
    double l,b,h;
    void input(){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter length , breadth and height of coboid ");
        l=sc.nextDouble();
        b=sc.nextDouble();
        h=sc.nextDouble();
        sc.close();
    }
    void display(){
        System.out.println("length="+l);
        System.out.println("breadth="+b);
        System.out.println("height="+h);
    }
    double volume(){
        return l*b*h;
    }
    double area(){
        return 2*(l*b+l*h+b*h);
    }
}
public class CalculateVolumeOfCuboid {
    public static void main(String[] args) {
        Cuboid c=new Cuboid();
        c.input();
        c.display();
        System.out.println("volume of cubiod="+c.volume());
        System.out.println("area of cuboid ="+c.area());
    }
}
