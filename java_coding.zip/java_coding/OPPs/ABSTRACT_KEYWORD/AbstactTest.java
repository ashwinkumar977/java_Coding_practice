abstract class Test{
    abstract void display();
}

class A extends Test{
    int x;
    public A(int a){
        x=a;
    }
    void display(){
        System.out.println("x="+x);
    }
}
class B extends Test{
    String s;
    public B(String a){
        s=a;
    }
    void display(){
        System.out.println("String="+s);
    }
}
public class AbstactTest {
    public static void main(String[] args) {
       // Test t=new Test();  this is wrong method
       Test t;
       A a=new A(8);
       a.display();
       B b=new B("ashwin");
       b.display();
       t=new A(6);
       t.display();
       t=new B("kumar");
       t.display();
    }
}
