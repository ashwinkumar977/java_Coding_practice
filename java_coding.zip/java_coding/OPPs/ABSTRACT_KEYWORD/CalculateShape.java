abstract class Shape{
    double r;
    public Shape(double x){
        r=x;
    }
    void display(){
        System.out.println("radius="+r);
    }
    abstract double volume();
}
class Cone extends Shape{
    double h;
    public Cone(double x,double y){
        super(x);
        h=y;
    }
    void display(){
        super.display();
        System.out.println("height="+h);
    }
    double volume(){
        return 3.141*r*r*h/3;
    }
}
class Sphere extends Shape{
    public Sphere(double x){
        super(x);
    }
    double volume(){
        return 4/3*3.141*r*r*r;
    }
}
public class CalculateShape {
    public static void main(String[] args) {
        Shape s;
        s=new Cone(4.7, 5.3);
        s.display();
        System.out.println("volume of cone="+s.volume());
        s=new Sphere(6.8);
        s.display();
        System.out.println("volume of sphere="+s.volume());
    }
}