import java.util.Scanner;
class BankCustmer {
    int account_no;
    String name,address,accout_type;
    double balance;
    public BankCustmer(int x,String a,String b,String c,double n){
        account_no=x;
        name=a;
        address=b;
        accout_type=c;
        balance=n;
    }
    void display(){
        System.out.println("details of a bank custmer");
        System.out.println("accout number="+account_no);
        System.out.println("name="+name);
        System.out.println("address="+address);
        System.out.println("account type="+accout_type);
        System.out.println("balance="+balance);
    }
    double deposit(double amount){
        return balance+amount;
    }
    double withdraw(double amount){
        return balance-amount;
    }

    public static void main(String[] args) {
        do{
            System.out.println("press1, open account of custmer");
            System.out.println("press2, to display details of custmer");
            System.out.println("press3,to deposit amount of custmer");
            System.out.println("press4,to withdraw amount of custmer");
            System.out.println("press5, to quit");
            Scanner sc=new Scanner(System.in);
            System.out.println("*****************enter your choice *****************");
            int n=sc.nextInt();
            BankCustmer c=new BankCustmer();
            switch (n) {
                case 1:
                    System.out.println("enter details of custmer");
                    System.out.println("enter account number");
                    int account_no=sc.nextInt();
                    System.out.println("enter name of custmer");
                    String name=sc.next();
                    System.out.println("enter address of custmer");
                    String address=sc.next();
                    System.out.println("enter type of accout");
                    String accout_type=sc.next();
                    System.out.println("enter minimum balance of acount");
                    double balance=sc.nextDouble();
                    
                    break;
                case 2:
                    c.display();    
                    break;
                case 3:
                    System.out.println("enter amount, to deposit");
                    double depost_amount=sc.nextDouble();
                    System.out.println("total balance="+c.deposit(depost_amount));  
                    break;  
                case 4:
                    System.out.println("enter amount, to withdraw");
                    double withdraw_amount=sc.nextDouble();
                    System.out.println("total balance="+c.withdraw(withdraw_amount));   
                    break;  
                case 5:
                    System.exit(0);
                default:
                    System.out.println("invalid choice"); 
                    break;
            }
            sc.close();
        }while(true);
    }
}
