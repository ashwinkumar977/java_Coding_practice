/* example of single inheritance,method over-riding,and 
 * all purpose of super keyword
 */

//super class
class Shape{
    double l,b;
    public Shape(double x,double y){
        l=x;
        b=y;
    }
    void display(){
        System.out.println("length="+l);
        System.out.println("breadth="+b);
    }
}

class Cuboid extends Shape{
    double h;
    public Cuboid(double x,double y,double z){
        super(x, y); // 1st purpose of super keyword
        h=z;
    }
    void display(){  //method over-riding
        super.display(); // 2nd pupose of super keyword
        System.out.println("height="+h);
    }
    double volume(){
      //  return l*b*h;
        return super.l*super.b*h;  // 3rd purpose of super keyword
    }
}
public class CalculationCuboid {
    public static void main(String[] args) {
        Cuboid c=new Cuboid(5.4, 3.8, 4.7);
        c.display();
        System.out.println("volume of cuboid ="+c.volume());
    }
}
