/* example of single inheritance */

//super class
class Shape{
    double l,b;
    public Shape(double x,double y){
        l=x;
        b=y;
    }
    void display(){
        System.out.println("length="+l);
        System.out.println("breadth="+b);
    }
}

//sub class whose extends to super class Shape
class Rectangle extends Shape {
    public Rectangle(double x,double y){
       super(x,y);
    }
    double area(){
        return l*b;
    }
    double perimeter(){
        return 2*(l+b);
    }
}
/**
 * CalculationRectangle
 */
public class CalculationRectangle {
    public static void main(String[] args) {
        Rectangle r=new Rectangle(5.4, 3.8);
        r.display();
        System.out.println("area of rectangle="+r.area());
        System.out.println("perimeter of rectangle="+r.perimeter());
    }
}