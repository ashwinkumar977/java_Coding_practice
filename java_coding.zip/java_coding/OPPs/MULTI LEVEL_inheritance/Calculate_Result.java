/* example of multi-level inheritance */

import java.util.Scanner;
class Person{  //super class
    String name,address;
    int age;
    public Person(String a,int b,String c){
        name=a;
        age=b;
        address=c;
    }
    public void display(){
        System.out.println("Name="+name);
        System.out.println("Age="+age);
        System.out.println("Address="+address);
    }
}

class Student extends Person{
    int roll;
    String course;
    public Student(String a,int b,String c,int d,String e){
        super(a, b, c);
        roll=d;
        course=e;
    }
    public void display(){
        super.display();
        System.out.println("Roll="+roll);
        System.out.println("Course="+course);
    }
}
class Result extends Student{
    int sm1,sm2,sm3;
    public Result(String a,int b,String c,int d,String e,int f,int g,int h){
        super(a, b, c, d, e);
        sm1=f;
        sm2=g;
        sm3=h;
    }
    public void display(){
        super.display();
        System.out.println("Marks of three subject="+sm1+"\t"+sm2+"\t"+sm3);
    }
    void grade(){
        double avg=(sm1+sm2+sm3)/3;
        if(avg >=75){
            System.out.println("GRADE A");
        }
        else if(avg>=60 && avg <75){
            System.out.println("GRADE B");
        }
        else if(avg>=45 && avg <60){
            System.out.println("GRADE C");
        }
        else if(avg>=30 && avg <45){
            System.out.println("GRADE D");
        }
        else{
            System.out.println("FAIL");
        }
    }
}
/**
 * main class Calculate_Result
 */

public class Calculate_Result {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter name of person");
        String name=sc.next();
        System.out.println("Enter age of person");
        int age=sc.nextInt();
        System.out.println("Enter address of person");
        String address=sc.next();
        System.out.println("Enter roll number of student");
        int roll=sc.nextInt();
        System.out.println("Enter courseof Student ");
        String course=sc.next();
        System.out.println("Enter marks of three subject");
        int sm1=sc.nextInt();
        int sm2=sc.nextInt();
        int sm3=sc.nextInt();
        Result r=new Result(name, age, address, roll, course, sm1, sm2, sm3);
        r.display();
        r.grade();
        Result r1=new Result("ashwin", 20, "imamganj", 16, "BCA", 67, 65, 61);
        r1.display();
        r1.grade();
        sc.close();
    }
}