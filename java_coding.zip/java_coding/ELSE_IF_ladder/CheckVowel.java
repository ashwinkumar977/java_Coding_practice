import java.util.Scanner;
class CheckVowel
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any Alphabet");
        char c=sc.next().charAt(0);
        if (c=='a' ||c=='A' || c=='e'|| c=='E'||c=='i'||c=='I'||c=='o'||c=='O'||c=='U'||c=='u' ){
            System.out.println("input character is vowel");
        }    
        else
        {
            System.out.println("input character is consonent");
        }
        sc.close();
    }
}
