import java.util.Scanner;
class ResultCalculate {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter student marks of 3 subject");
        int m1=sc.nextInt();
        int m2=sc.nextInt();
        int m3=sc.nextInt();
        double total=m1+m2+m3;
        double avg=total/3;
        System.out.println("total marks="+total);
        System.out.println("avg marks="+avg);
        if(avg>= 90){
            System.out.println("grade="+'A');
        }
        else if(avg>=75 && avg <90){
            System.out.println("grade="+'B');
        }
        else if(avg>=60 && avg<75){
            System.out.println("grade="+'C');
        }
        else if(avg>=45 && avg<60){
            System.out.println("grade="+'D');    
        }
        else if(avg <45){
            System.out.println("grade="+'E');
        }
        sc.close();
    }
}

