//to perform arithematic operation on input two number on the basis of arithematic operator
import java.util.Scanner;
class Calculator
{
   public static void main(String arr[])
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter any two number");
      int a=sc.nextInt();
      int b=sc.nextInt();
      System.out.println("enter any operator");
      char op=sc.next().charAt(0);
      if(op=='+')
       System.out.println("sum="+(a+b));
      else if(op== '-')
       System.out.println("substract="+(a-b));
      else if(op== '*')
       System.out.println("muliplication="+(a*b));
      else if(op== '/')
       System.out.println("division="+(a/b));
      else if(op=='%')
       System.out.println("modulus="+(a%b));
      else
       System.out.println("invalid input operator");
      sc.close(); 
           
   }
}