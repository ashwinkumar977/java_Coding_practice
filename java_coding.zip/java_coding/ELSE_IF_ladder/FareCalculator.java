import java.util.Scanner;
class FareCalculator {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number of person");
        int p=sc.nextInt();
        System.out.println("Enter number of children");
        int c=sc.nextInt();
        System.out.println("Enter distance in kilometer");
        int d=sc.nextInt();
        double total=0;
        if(d>=1000){
            total=(4000*p)+(4000*50/100*c);
        }
        else if (d>=750 && d<1000){
            total=(3000*p)+(3000*50/100*c);
        }
        else if(d>=500 && d<750){
            total=(2000*p)+(2000*50/100*c);
        }
        else if(d<500){
            total=(1500*p)+(1500*50/100*c);
        }
        System.out.println("total fare="+total);
        sc.close();
    }
    
}
