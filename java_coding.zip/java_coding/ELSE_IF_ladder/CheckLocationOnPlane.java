import java.util.Scanner;
class CheckLocationOnPlane {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("co-ordinate of the loction");
        int x=sc.nextInt();
        int y=sc.nextInt();
        if(x==0 && y==0){
            System.out.println("points lies on the origin");
        }
        else if(x==0 && y!=0){
            System.out.println("points lies on the y-axis");
        }
        else if(x!=0 && y==0){
            System.out.println("points lies on the x-axis");
        }
        else{
            System.out.println("points lies on any the other location");
        }
        sc.close();

    }   
}
