import java.util.Scanner;
class CheckLocationOnCircle {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter points of the loction");
        int x=sc.nextInt();
        int y=sc.nextInt();
        int d=x*x+y*y;
        System.out.println("enter radius of the circle");
        int r=sc.nextInt();
        if(d<r*r){
            System.out.println("points lies within a circle");
        }
        else if(d>r*r){
            System.out.println("points lies outside a circle");
        }        
        else if(d==r*r){
            System.out.println("points lies on the circle");
        }
        sc.close();
    }
    
}
