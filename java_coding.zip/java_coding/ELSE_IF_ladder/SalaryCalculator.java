import java.util.Scanner;
class SalaryCalculator {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter basic salary");
        double bsal=sc.nextDouble();
        double da=bsal*50/100;
        double hr=bsal*8/100;
        double gsal=bsal+da+hr+1000;
        System.out.println("gross salary="+gsal);
        double incometax=0;
        if( gsal>=60000){
             incometax=bsal*20/100;
        }
        else if(gsal>=45000 && gsal<60000){
            incometax=bsal*15/100;
        }
        else if(gsal>=30000 && gsal<45000){
            incometax=bsal*10/100;
        }
        else if (gsal<30000) {
            incometax=0;
        }
        double nsal=gsal-incometax;
        System.out.println("net salary="+nsal);
        sc.close();
    }
    
}
