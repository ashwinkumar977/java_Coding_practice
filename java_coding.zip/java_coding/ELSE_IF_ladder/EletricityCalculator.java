import java.util.Scanner;
class EletricityCalculator{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter unit of electricity bill");
        int u=sc.nextInt();
        double total=0;
        if(u<=100){
            total=u*7;
        }
        else if (u>100 && u<=200){
            total=600+((u-100)*9);
        }
        else if (u>200 && u<=300){
            total=1400+((u-200)*11);
        }
        else if(u>300){
            total=2300+((u-300)*13);
        }
        System.out.println("total amount="+total);
        sc.close();
    }
    
}
