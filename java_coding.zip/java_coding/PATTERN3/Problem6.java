/*
    problem6
    EEEEE
    DDDD
    CCC
    BB
    A

     */
    public class Problem6 {
        public static void main(String[] args) {
            int k=69;
            for(int i=69;i>=65;i--){
                for(int j=65;j<=i;j++){
                    System.out.print((char)k);
                }
                k--;
                System.out.println();
            }
        }
        
    }                     
                                                                                                                                            