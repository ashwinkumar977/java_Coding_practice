/*
    problem7
    abcde
    abcd
    abc
    ab
    a

     */
    public class Problem7 {
        public static void main(String[] args) {
            for(int i=101;i>=97;i--){
                for(int j=97;j<=i;j++){
                    System.out.print((char)j);
                }
                System.out.println();
            }
        }
        
    }                     
                                                                                                                                            
