package p;
public class Larger {
    public static int max(int a,int b){
        return a>b?a:b;
    }    
}
