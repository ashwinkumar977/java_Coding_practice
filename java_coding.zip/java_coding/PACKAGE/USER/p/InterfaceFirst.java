package p;

public interface InterfaceFirst {
    void show();
    final static double PI=3.141;
}
