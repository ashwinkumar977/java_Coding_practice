package p;
public class Smaller {
    public static int min(int a,int b){
        return a<b?a:b;
    }    
}
