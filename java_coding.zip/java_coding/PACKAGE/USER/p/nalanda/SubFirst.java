package p.nalanda;
public class SubFirst {
    public void show(){
        System.out.println("making a part of sub_package");
    }
}
