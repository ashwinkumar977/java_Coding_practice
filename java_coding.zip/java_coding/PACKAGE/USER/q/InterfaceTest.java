/* create a package P that has interfaceFirst with show method
 * and symbolic constant PI.create another package Q that import
 * package P that has interfacetest class with main method that
 * impliments interfaceFirst interface it define abstract method
 */
package q;                           
import p.InterfaceFirst;

public class InterfaceTest implements InterfaceFirst{
    public void show(){
        System.out.println("making a interface a part of package");
    }
    public static void main(String[] args) {
        InterfaceTest t=new InterfaceTest();
        t.show();
        System.out.println("PI="+PI);
    }
}
