package q;
import p.*;
import java.util.Scanner;
public class Test1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two integer number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int s=Smaller.min(a,b);
        System.out.println("smaller number="+s);
        sc.close();
    }
}
