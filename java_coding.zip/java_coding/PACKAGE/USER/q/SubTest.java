package q;
import p.nalanda.*;
public class SubTest {
    public static void main(String[] args) {
        SubFirst s=new SubFirst();
        s.show();
    }
}
