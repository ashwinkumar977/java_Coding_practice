package q;
import p.Larger;
import java.util.Scanner;
public class Test {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two integer number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int l=Larger.max(a, b);
        System.out.println("larger number="+l);
        sc.close();
    }
}
