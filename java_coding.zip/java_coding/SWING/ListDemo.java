import java.awt.*;
//import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
public class ListDemo extends JFrame implements ListSelectionListener{
    JList<String> item;
    public ListDemo(){
        Container c=getContentPane();
        c.setLayout(new FlowLayout());
        JLabel lbl= new JLabel("Select option from a list Box:");
        String color[]={"keyboard","moniter","scanner","mouse","printer"};
        item=new JList<>(color);
        item.setVisibleRowCount(4);
        item.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane jsp= new JScrollPane(item);
        c.add(lbl);
        c.add(jsp);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(250,200);
        setTitle("ListDemo");
        setVisible(true); 
        item.addListSelectionListener(this);
    }
    public void valueChanged(ListSelectionEvent e){
       String sel= item.getSelectedValue();
       JOptionPane.showMessageDialog(this,"Selected Option is : "+sel);
    }
    public static void main(String[] args) {
        new ListDemo();
    }
}
