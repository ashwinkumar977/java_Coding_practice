import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DailogDemo extends JFrame implements ActionListener{
    JButton btn1, btn2, btn3;
    JTextField txt;
    public DailogDemo(){
        Container c=getContentPane();
        c.setLayout(new FlowLayout());
        JLabel lbl= new JLabel("Message:");
        txt=new JTextField(20);
        btn1=new JButton("Message");
        btn3=new JButton("Confirm");
        btn2=new JButton("Input");
        c.add(lbl);
        c.add(txt);
        c.add(btn2);
        c.add(btn1);
        c.add(btn3);
        setSize(320,250);
        setTitle("DailogDemo");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Message")){
            JOptionPane.showMessageDialog(this,txt.getText());
        }
        if(s.equals("Input")){
            String str=JOptionPane.showInputDialog(this,"Enter Your Messege:");
            txt.setText(str);
        }
        if(s.equals("Confirm")){
           int n= JOptionPane.showConfirmDialog(this,txt.getText());
           if(n==JOptionPane.YES_OPTION){
               JOptionPane.showMessageDialog(this,"You are progressive..");
           }
           else if(n==JOptionPane.NO_OPTION){
               JOptionPane.showMessageDialog(this,"You are living in past..");
           }
           else{
               JOptionPane.showMessageDialog(this,"Thanks for Being Undecidable!");
           }
        }
    }
    public static void main(String[] args) {
        new DailogDemo();
    }
}
