import java.awt.*;
//import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
public class TableDemo extends JFrame implements ListSelectionListener{
    JTable table;
    public TableDemo(){
        Container c=getContentPane();
        c.setLayout(new FlowLayout());
        JLabel lbl=new JLabel("Select data from a cell:");
        String[] header={"Roll","Name","Course","MobNo"};
        String[][] data = {
            { "101", "Anil", "MCA", "9308754906" },
            { "102", "Sunil", "BCA", "9308754907" },
            { "103", "Rahul", "BBA", "9308754908" },
            { "104", "Ravi", "MBA", "9308754909" }
        };
        table=new JTable(data,header);
        JScrollPane jsp=new JScrollPane(table);
        table.setCellSelectionEnabled(true);  
        ListSelectionModel select= table.getSelectionModel();  
        select.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);  
        c.add(lbl);
        c.add(jsp);
        setSize(500,450);
        setTitle("Table Demo");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        select.addListSelectionListener(this);
    }
    public void valueChanged(ListSelectionEvent e){
     int i=table.getSelectedRow();
     int j=table.getSelectedColumn();
     String str=table.getValueAt(i, j).toString();
     JOptionPane.showMessageDialog(this,"Selected value:"+str);
    }
    public static void main(String[] args) {
        new TableDemo();
    }
}
