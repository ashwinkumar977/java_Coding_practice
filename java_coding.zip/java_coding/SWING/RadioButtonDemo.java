import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RadioButtonDemo extends JFrame implements ItemListener{
    static JRadioButton r1,r2,r3,r4,r5,r6;
    static JTextField txt1,txt2;
    int n;
    public RadioButtonDemo(){
        Container c=getContentPane(); 
        c.setLayout(new FlowLayout());
        JPanel p1=new JPanel(new GridLayout(2, 2));
        JLabel lb1=new JLabel("Enter any Number");
        JLabel lb2=new JLabel("Result");
        txt1=new JTextField(10);
        txt2=new JTextField(10);
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);

        JPanel p2=new JPanel(new GridLayout(2, 3));
        r1=new JRadioButton("Spy", true);
        r2=new JRadioButton("Prime", false);
        r3=new JRadioButton("Perfect", false);
        r4=new JRadioButton("Niven", false);
        r5=new JRadioButton("Clear", false);
        r6=new JRadioButton("Close", false);
        ButtonGroup bg=new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        bg.add(r3);
        bg.add(r4);
        bg.add(r5);
        bg.add(r6);

        p2.add(r1);
        p2.add(r2);
        p2.add(r3);
        p2.add(r4);
        p2.add(r5);
        p2.add(r6);

        c.add(p1);
        c.add(p2);
        setSize(300, 300);
        setVisible(true);
        setTitle("RadioButtonDemo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        r1.addItemListener(this);
        r2.addItemListener(this);
        r3.addItemListener(this);
        r4.addItemListener(this);
        r5.addItemListener(this);
        r6.addItemListener(this);
    }
    public void itemStateChanged(ItemEvent e){
        n=Integer.parseInt(txt1.getText());
        if(r1.isSelected()){
            int s=0,m=1;
            while(n>0){
                int r=n%10;
                s=s+r;
                m=m*r;
                n=n/10;
            }
            if(s==m ){
                txt2.setText("spy number ");
            }
            else{
                txt2.setText("not spy number");
            }
        }
        else if(r2.isSelected()){
            int i=2,flag=0;
            while (i<=n/2) {
                if(n%i==0){
                    flag=1;
                }
                i++;
            }
            if(flag==1){
                txt2.setText("Not Prime Number");
            }
            else{
                txt2.setText("Prime Number");
            }

        }
        else if(r3.isSelected()){
            int n1=n,sum=0,i=1;
            while ( i<=n/2) {
                if(n%i==0){
                    sum=sum+i;
                }
                i++;
            }
            if(sum==n1){
                txt2.setText("perfect number");
            }
            else{
                txt2.setText("not perfect number");
            }
        }
        else if(r4.isSelected()){
            int s=0,n1=n;
            while (n>0) {
                int r=n%10;
                s=s+r;
                n=n/10;
            }
            if(n1%s==0){
                txt2.setText("Niven Number");
            }
            else{
                txt2.setText("not Niven Number");
            }
        }
        else if(r5.isSelected()){
            txt1.setText("");
            txt2.setText("");
        }
        else if(r6.isSelected()){
            System.exit(ABORT);
        }
    }
    public static void main(String[] args) {
        new RadioButtonDemo();
    }
}
