import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class MyNotepad extends JFrame implements ActionListener{
    static JTextArea txt1;
    public MyNotepad(){
        Container c=getContentPane();
        txt1=new JTextArea(20,50);
        JButton b1=new JButton("Close");

        JMenuBar mb=new JMenuBar();
        JMenu fileMenu=new JMenu("File");
        JMenu editMenu=new JMenu("Edit");
        JMenu formatMenu=new JMenu("Format");
        JMenu helpMenu=new JMenu("Help");
        JMenuItem newFileItem=new JMenuItem("New");
        JMenuItem openFileItem=new JMenuItem("Open");
        JMenuItem saveasFileItem=new JMenuItem("Save as");
        JMenuItem printFileItem=new JMenuItem("Print");
        JMenuItem exitFileItem=new JMenuItem("Exit");

        JMenuItem cutEditItem=new JMenuItem("Cut");
        JMenuItem copyEditItem=new JMenuItem("Copy");
        JMenuItem pasteEditItem=new JMenuItem("Paste");
        JMenuItem findEditItem=new JMenuItem("Find");
        JMenuItem replaceyEditItem=new JMenuItem("Replace");
        JMenuItem selectAllEditItem=new JMenuItem("Select all");
        JMenuItem gotoEditItem=new JMenuItem("Goto");
        JMenuItem deleteEditItem=new JMenuItem("Delete");

        JMenuItem dateTimeFormatItem=new JMenuItem("Date & Time");
        JMenuItem bkcolorFormatItem=new JMenuItem("BackGround Color");
        JMenuItem frcolorFormatItem=new JMenuItem("ForeGround Color");

        JMenuItem aboutMynotepadHelpItem=new JMenuItem("About Mynotepad");
        
        fileMenu.add(newFileItem);
        fileMenu.add(openFileItem);
        fileMenu.add(printFileItem);
        fileMenu.add(saveasFileItem);
        fileMenu.add(exitFileItem);

        editMenu.add(cutEditItem);
        editMenu.add(copyEditItem);
        editMenu.add(pasteEditItem);
        editMenu.add(findEditItem);
        editMenu.add(replaceyEditItem);
        editMenu.add(gotoEditItem);
        editMenu.add(selectAllEditItem);
        editMenu.add(deleteEditItem);

        formatMenu.add(dateTimeFormatItem);
        formatMenu.add(bkcolorFormatItem);
        formatMenu.add(frcolorFormatItem);

        helpMenu.add(aboutMynotepadHelpItem);

        mb.add(fileMenu);
        mb.add(editMenu);
        mb.add(formatMenu);
        mb.add(helpMenu);

        setTitle("MyNotepad");
        c.setLayout(new FlowLayout());
        c.add(mb,BorderLayout.NORTH);
        c.add(txt1,BorderLayout.CENTER);
        c.add(b1,BorderLayout.SOUTH);
        setVisible(true);
        setSize(500,420);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        b1.addActionListener(this);
        newFileItem.addActionListener(this);
    }
    public static void main(String[] args) {
        new MyNotepad(); 
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Close")){
            System.exit(ABORT);
        }

    }
}
