import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.*;
import javax.swing.tree.DefaultMutableTreeNode;
public class TreeDemo extends JFrame implements TreeSelectionListener{
    JTree jt;
    public TreeDemo(){
     
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,400);

        //creating Root dir....
        DefaultMutableTreeNode dir =new DefaultMutableTreeNode("Director");
        DefaultMutableTreeNode project =new DefaultMutableTreeNode("ProjectLeader");
        //creating Parent dir....
        DefaultMutableTreeNode Team1 =new DefaultMutableTreeNode("TeamLeader1");
        DefaultMutableTreeNode Team2 =new DefaultMutableTreeNode("TeamLeader2");

        //creating child dir.....
        DefaultMutableTreeNode prog1 =new DefaultMutableTreeNode("Progammer1");
        DefaultMutableTreeNode prog2 =new DefaultMutableTreeNode("Progammer2");
        DefaultMutableTreeNode dev1 =new DefaultMutableTreeNode("Developer1");
        DefaultMutableTreeNode dev2 =new DefaultMutableTreeNode("Developer2");

        //adding in to project
        dir.add(project);
        project.add(Team1);
        Team1.add(prog1);
        Team1.add(prog2);
        project.add(Team2);
        Team2.add(dev1);
        Team2.add(dev2);

        jt=new JTree(dir);
        JScrollPane jp= new JScrollPane(jt);
        add(jp);
        setTitle("TreeDemo");
        setVisible(true);

        jt.addTreeSelectionListener(this);

    }
    public void valueChanged(TreeSelectionEvent e){
        String s=e.getPath().toString();
        JOptionPane.showMessageDialog(this,"FullPath of Selected data:"+s);
    }
    public static void main(String[] args) {
        new TreeDemo();
    }
}