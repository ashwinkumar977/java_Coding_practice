import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class SwingDemo extends JFrame implements ActionListener{
    JButton btn;
    public SwingDemo(){
        Container c=getContentPane();
        c.setLayout(new FlowLayout());
        btn=new JButton("Depressed");
        c.add(btn);
        setSize(300, 250);
        setTitle("Swing Demo");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        btn.addActionListener(this);
    }
    @SuppressWarnings("deprecation")
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Depressed")){
            btn.setLabel("Pressed");
        }
        else{
            btn.setLabel("Depressed");
        }
    }
    public static void main(String[] args) {
        new SwingDemo();    
    }
}