import java.util.Scanner;
/**
 * IncrementDecrement
 */
public class IncrementDecrement {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int x=a++;   //postfix increment
        int y=++b;  //prefix increment
        System.out.println("a="+a+"\t x="+x);
        System.out.println("b="+b+"\t y="+y);
        x=--a;    // prefix decrement
        y=b--;   //postfix decrement
        System.out.println("a="+a+"\t x="+x);
        System.out.println("b="+b+"\t y="+y);
        a++;    //postfix increment
        ++b;    //prefix increment
        x--;    //postfix decrement
        --y;   //prefix decrement
        System.out.println("a="+a+"\t x="+x);
        System.out.println("b="+b+"\t y="+y);
        sc.close();
    }
}