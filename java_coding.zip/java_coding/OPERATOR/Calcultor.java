//cap to perform all arithematic operation on basis of arithematic operator 
import java.util.Scanner;
public class Calcultor {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two number");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        System.out.println("enter any operator ");
        char op=sc.next().charAt(0);
        switch (op) {
            case '+':System.out.println("sum="+(a+b));break;
            case '-':System.out.println("substract="+(a-b));break;
            case '*':System.out.println("multiply="+(a*b));break;
            case '/':System.out.println("division="+(a/b));break;
            case '%':System.out.println("reminder="+(a%b));break;        
            default:System.out.println("invalid operator");break;
        }
        sc.close();
    }
}