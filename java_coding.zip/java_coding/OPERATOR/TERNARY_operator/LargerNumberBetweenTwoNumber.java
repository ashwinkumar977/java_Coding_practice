/* to find larger number between two number */
import java.util.Scanner;
public class LargerNumberBetweenTwoNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two number");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        double l;
        l=a>b ? a:b;
        System.out.println("larger number ="+l);
        sc.close();
    }   
}
