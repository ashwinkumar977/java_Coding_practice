/* to check input year is leap year or not */
import java.util.Scanner;
public class CheckLeapYear {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("ENTER ANY year");
        int y=sc.nextInt();
        String s=y%4==0 && y%100!=0 ? "leap  year ": y%400==0 ? "leap year":"not leap year";
        System.out.println("input year is "+ s);
        sc.close();
    }
}

