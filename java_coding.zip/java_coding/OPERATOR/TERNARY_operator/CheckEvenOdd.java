/**
 * cap in java to check input number is even or odd using ternary operator
 */
import java.util.Scanner;
public class CheckEvenOdd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any number");
        int n=sc.nextInt();
        //n%2==0 ? System.out.println(" input number is even "):System.out.println("input number is odd");
        String s=n%2==0 ? "even" :"odd";
        System.out.println("input number is "+ s);
        sc.close();
    }

    
}