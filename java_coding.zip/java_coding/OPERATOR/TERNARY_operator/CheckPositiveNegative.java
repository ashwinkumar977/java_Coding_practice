/* to check input number is positive or negative */
import java.util.Scanner;
public class CheckPositiveNegative {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("ENTER ANY NUMBER");
        int n=sc.nextInt();
        String s=n>=0 ? "positive":"negative";
        System.out.println("input number is "+ s);
        sc.close();
    }
}
