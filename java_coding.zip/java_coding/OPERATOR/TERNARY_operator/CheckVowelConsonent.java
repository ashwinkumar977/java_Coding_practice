// to check input alphabet is vowel or consonent
import java.util.Scanner;
public class CheckVowelConsonent {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any alphabet ");
        char c=sc.next().charAt(0);
        String s=c=='A'||c=='a'||c=='E'||c=='e'||c=='I'||c=='i'||c=='O'||c=='o'||c=='U'||c=='u' ? "vowel"  : "consonent";
        System.out.println("input alphabet is "+s);
        sc.close();
    }
    
}
