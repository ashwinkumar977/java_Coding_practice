/* to find smallest number among three number */
import java.util.Scanner;
public class SmallestNumberAmongThreeNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any three number");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        double c=sc.nextDouble();
        double s;
        s=a<b ? a<c ? a:c : b<c ? b:c;
        System.out.println("largest number ="+s);
        sc.close();
    }   
}
            