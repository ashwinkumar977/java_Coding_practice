/* to check input age of person is eligible or not elegible */
import java.util.Scanner;
public class CheckEligibleVoted {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any person age");
        int n=sc.nextInt();
        String s=n>=18 ? "eligible for voting ":"not eligible for voting";
        System.out.println("input person age  is "+ s);
        sc.close();
    }
}


