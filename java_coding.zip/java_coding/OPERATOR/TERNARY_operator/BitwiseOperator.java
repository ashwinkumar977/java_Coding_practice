//example of binary bitwise operator
import java.util.Scanner;
public class BitwiseOperator {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.err.println("enter any two number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        System.out.println("bitwise AND="+(a&b));
        System.out.println("bitwise OR="+(a|b));
        System.out.println("bitwise left shift="+(b<<2));
        System.out.println("bitwise right shift="+(a>>2));
        System.out.println("unsigned right shift="+(a>>>3));
        sc.close();
    }
}
