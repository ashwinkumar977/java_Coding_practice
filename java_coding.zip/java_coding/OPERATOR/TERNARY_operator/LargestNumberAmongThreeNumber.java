/* to find largest number among three number */
import java.util.Scanner;
public class LargestNumberAmongThreeNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any three number");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        double c=sc.nextDouble();
        double l;
        l=a>b ? a>c ? a:c : b>c ? b:c;
        System.out.println("largest number ="+l);
        sc.close();
    }   
}
            