// to check input alphabet is uppercase or lowercase
import java.util.Scanner;;
public class CheckUppercaseLowercase {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any alphabet");
        char c=sc.next().charAt(0);
        String s=c>=65 && c<=90 ? "uppercase":"lowercase";
        System.out.println("input alphabet is "+s);
        sc.close();
    }
    
}
