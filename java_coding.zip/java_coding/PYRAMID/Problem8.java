/*
 *     problem8
 *          5
 *         545
 *        54345
 *       5432345
 *      543212345
 *       5432345
 *        54345
 *         545
 *          5
 */
public class Problem8 {
    public static void main(String[] args) {
        for(int i=5;i>=1;i--){
            for(int j=i;j>1;j--){
                System.out.print(' ');
            }
            for(int j=5;j>=i;j--){
                System.out.print(j);
            }
            for(int j=1+i;j<=5;j++){
                    System.out.print(j);
            }
            System.out.println();
        }
        for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                System.out.print(' ');
            }
            for(int j=5;j>=i+1;j--){
                System.out.print(j);
            }
            for(int j=i+2;j<=5;j++){
                System.out.print(j);
            }
            System.out.println();
        }
    }
    
}
