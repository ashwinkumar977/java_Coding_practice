/*
 *     problem3
 *     A       A
 *     AB     BA
 *     ABC   CBA
 *     ABCD DCBA
 *     ABCDEDCBA
 */
public class Problem4 {
    public static void main(String[] args) {
        int k=71;
        for(int i=65;i<=69;i++){
            for(int j=65;j<=i;j++){
                System.out.print((char)j);
            }
            for(int j=65;j<=k;j++){
                System.out.print(' ');
            }
            k=k-2;
            for(int j=i;j>=65;j--){
                if(j!=69){
                    System.out.print((char)j);
                }
            }
            System.out.println();
        }
    }    
}
