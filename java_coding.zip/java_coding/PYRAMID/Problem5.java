/*
 *     problem5
 * 
 *     123454321
 *     1234 4321
 *     123   321
 *     12     21
 *     1       1
 */
public class Problem5 {
    public static void main(String[] args) {
        int k=1;
        for(int i=5;i>=1;i--){
            for(int j=1;j<=i;j++){
                System.out.print(j);
            }
            if(i!=5){
                for(int j=1;j<=k;j++){
                    System.out.print(' ');
                }
                k=k+2;
            }
            for(int j=i;j>=1;j--){
                if(j!=5){
                    System.out.print(j);
                }
            }
            System.out.println();
        }
        
    }    
}

