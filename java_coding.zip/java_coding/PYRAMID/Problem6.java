/*
 *     problem6
 * 
 *     ABCDEDCBA
 *     ABCD DCBA
 *     ABC   CBA
 *     AB     BA
 *     A       A
 */
public class Problem6 {
    public static void main(String[] args) {
        int k=65;
        for(int i=69;i>=65;i--){
            for(int j=65;j<=i;j++){
                System.out.print((char)j);
            }
            if(i!=69){
                for(int j=65;j<=k;j++){
                    System.out.print(' ');
                }
                k=k+2;
            }
            for(int j=i;j>=65;j--){
                if(j!=69){
                    System.out.print((char)j);
                }
            }
            System.out.println();
        }
        
    }    
}


