import java.util.Scanner;
/**
 * CheckEquilateralTriangle
 */
public class CheckEquilateralTriangle {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter sides of triangle");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        if(a==b && b==c){
            System.out.println("input sides of  triangle is eqilateral triangle ");
        }
        else{
            System.out.println("input sides of triangle is not eqilateral triangle");
        }
        sc.close();
    }
}