//to check input year is leap year or not
import java.util.Scanner;
class CheckLeapYear
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any year");
       int a=sc.nextInt();
       if(a%4==0)
         System.out.println(a +" is leap year");
       else
         System.out.println(a +" is not leap year");

       sc.close();  
    }
    
}