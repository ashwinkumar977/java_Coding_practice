//to check input number is positive or negative 
import java.util.Scanner;
class CheckPositiveNegative
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any integer number");
       int n=sc.nextInt();
       if(n >=0)
         System.out.println(n +" is positive number");
       else
         System.out.println(n +" is negative number");
    }
}