import java.util.Scanner;
class Check
{
     public static void main(String[] args)
     {
        double cp,sp;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter cp & sp");
        cp=sc.nextDouble();
        sp=sc.nextDouble();
        if(cp>sp)
        System.out.println( "total profit="+ (cp-sp));
        else
        System.out.println("total loss="+(sp-cp));
        sc.close();
     } 
}