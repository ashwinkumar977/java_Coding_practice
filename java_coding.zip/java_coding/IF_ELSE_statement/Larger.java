//to find larger number between two number
import java.util.Scanner;
class Larger
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any two integer number");
       int a=sc.nextInt();
       int b=sc.nextInt();
       if(a>b)
         System.out.println(a +" is larger number");
       else
         System.out.println(b +" is larger number");
    }
}