/*
 *   press1 ,to calculate prime factor of input number
 *   press2, to check input number is spy number or not
 *   press3, to check input number is pollindrome number or not
 *   press4, to quit
 */
import java.util.Scanner;
class Menu1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        do{
            
            System.out.println("press1 , to calulate prime factor ");
            System.out.println("press2, to check Spy number");
            System.out.println("press3, to check pollindrome number ");
            System.out.println("press4,to quit");
            System.out.println("****************** enter your choice *****************");
            int ch=sc.nextInt();
            if(ch==1){
                System.out.println("enter any number");
                int n=sc.nextInt();
                int i=1;
                while (i<=n) {
                    if(n%i==0){
                        System.err.print("\t"+i);
                    }
                    i++;
                }
            }
            else if(ch==2){
                System.out.println("enter any number");
                int n=sc.nextInt();
                int s=0,m=1;
                while(n>0){
                    int r=n%10;
                    s=s+r;
                    m=m*r;
                    n=n/10;
                }
                if(s==m ){
                    System.out.println(" input number is spy number ");
                }
                else{
                    System.out.println("input number is not spy number");
                }
                
            }
            else if(ch==3){
                System.out.println("enter any number");
                int n=sc.nextInt();
                int r,n1=n,rv=0;
                while (n>0) {
                    r=n%10;
                    rv=rv*10+r;
                    n=n/10;
                }
                if(rv==n1){
                    System.out.println("input nuber is pollindrome number");
                }
                else{
                    System.out.println("input number is not pollindrome number");
                }
            }
            else if(ch==4){
                System.exit(0);
            }
            else{
                System.out.println("invalid choice");
            }
        }while(true);
        
    }   
}
