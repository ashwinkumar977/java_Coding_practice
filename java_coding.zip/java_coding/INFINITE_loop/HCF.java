/* cap to calculate HCF of input number using infinite loop */
/**
 * HCF
 */
import java.util.Scanner;
 public class HCF {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        do{
            int r=a%b;
            if(r==0){
                System.out.println("HCF="+b);
                break;
            }
            a=b;
            b=r;
        }while(true);
        sc.close();
    }
}