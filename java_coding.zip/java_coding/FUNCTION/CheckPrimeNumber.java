/* cap to check input number is prime number or not. by using the concept of function that does not accept a values but returning a values  */
import java.util.Scanner;
public class CheckPrimeNumber {
    static int IsPrime(){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int i=2,p=1;
        while (i<=n/2) {
            if(n%i==0){
                p=0;
                break;
            }
            i++;
        }
        sc.close();
        return p;
    }
    public static void main(String[] args) {
        int p;
        p=IsPrime();
        if(p==1){
            System.out.println("input number is prime number");
        }
        else{
            System.out.println("input number is not prime number");
        }
    }
    
}
