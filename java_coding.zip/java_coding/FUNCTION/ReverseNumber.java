/* cap to reverse input number by using function that does not accept and returning a values */
import java.util.Scanner;
/**
 * ReverseNumber
 */
public class ReverseNumber {

    static void Reverse(){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int r,rv=0;
        while (n>0) {
            r=n%10;
            rv=rv*10+r;
            n=n/10;
        }
        System.out.println("reverse number="+rv);
        sc.close();
    }
    public static void main(String[] args) {
        Reverse();
    }
}