/*cap to calculate factorial of input number. by using the concept of function that accept a values but doesnot returning a values   */
import java.util.Scanner;
public class CalculateFactorial {
    static void Factorial(int n){
        int f=1;
        while (n>=1) {
            f=f*n;
            n--;
        }
        System.out.println("factorial of input number="+f);
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int x=sc.nextInt();
        Factorial(x);
        sc.close();
    }
}
