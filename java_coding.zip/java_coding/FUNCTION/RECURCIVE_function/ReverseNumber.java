/* cap in java to reverse digit of input number by using recursive function */
import java.util.Scanner;
public class ReverseNumber {
    static int  reverse(int n){
        if(n>0){
            int r=n%10;
            System.out.print(r);
            n=reverse(n/10);
        }
        return 0;    
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        reverse(n);
        sc.close();
    }
    
}
