/* cap to calculate power of input two number by using recursive function */
import java.util.Scanner;
public class CalculatePower {
    static int power(int a,int b){
        int p=1;
        if(b>0){
            p=a*power(a,b-1);
        }
        return p;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two number");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int p=power(a, b);
        System.out.println("power of input number="+p);
        sc.close();
    }
}
