/*cap to calculate sum of 10 natural number by using recursive function */
public class Sum10NaturalNumber {   
    static int sum(){
        int s=0;
        int i=1;
        while (i<=10) {
            int r=sum();
            s=s+r;
            i++;
        }
        return s;
    }
    public static void main(String[] args) {
        int s=0;
        s=sum();
        System.out.println("sum of 10 natural number="+s);
    }
}
