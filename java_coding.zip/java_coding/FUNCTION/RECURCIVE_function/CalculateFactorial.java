/* cap to calculate factorial of input number by using recursive function */
import java.util.Scanner;
/**
 * CalculateFactorial
 */
public class CalculateFactorial {

    static int factorial(int n){
        int f=1;
        if(n>0){
            f=n*factorial(n-1);
        }
        return f;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int f=factorial(n);
        System.out.println("factorial of input number="+f);
        sc.close();
    }
}