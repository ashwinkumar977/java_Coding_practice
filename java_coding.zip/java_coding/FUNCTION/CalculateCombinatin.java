/* cap to calculate value of combination. by using the concept of function that accept and returning a values */
import java.util.Scanner;

public class CalculateCombinatin {
    static int Factorial(int n){
        int f=1;
        while (n>=1) {
            f=f*n;
            n--;
        }
        return f;
    }
    static int Combination(int n,int r){
        return (Factorial(n)) / (Factorial(r)*Factorial(n-r));
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter value of n & r to calculate combination");
        int n=sc.nextInt();
        int r=sc.nextInt();
        int result=Combination(n, r);
        System.out.println("result of combination="+result);
        sc.close();
    }
    
}
