/* cap to calculate value of permution. by using the concept of function that accept and returning a values */
import java.util.Scanner;
public class CalculatePermutation {
    static int Factorial(int n){
        int f=1;
        while (n>=1) {
            f=f*n;
            n--;
        }
        return f;
    }
    static int Permutation(int n,int r){
        return Factorial(n)/Factorial(r);
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter value of n & r to calculate permutation");
        int n=sc.nextInt();
        int r=sc.nextInt();
        int result=Permutation(n, r);
        System.out.println("result of permutation="+result);
        sc.close();
    }
    
}
