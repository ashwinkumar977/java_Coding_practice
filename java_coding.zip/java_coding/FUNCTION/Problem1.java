/* sin(x)=x - x^3/3! + x^5/5! - x^7/7! + ........... n   */
import java.util.Scanner;
public class Problem1 {
    static int Factorial(int n){
        int f=1;
        while (n>=1) {
            f=f*n;
            n--;
        }
        return f;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int sign=1,f;
        for(int i=1;i<=n;i=i+2){
            f=Factorial(i);
            System.out.print("x^"+i+"/"+f+"\t ");
            sign=sign*-1;
           // System.out.print(sign);
        }     
        sc.close();
    }
    
}
