//to calculate area and perimeter of rectangle
import java.util.Scanner;
class Rectangle
{
    public static void main(String[] args) 
    {
         Scanner sc=new Scanner(System.in) ;
         System.out.print("enter length and breadth of Rectangle=");
         double l=sc.nextDouble();
         double b=sc.nextDouble();
         double area=l*b;
         double perimeter=2*(l+b);
         System.out.println("area of rectangle="+ area +" \n perimeter of rectangle="+ perimeter);
    }
}