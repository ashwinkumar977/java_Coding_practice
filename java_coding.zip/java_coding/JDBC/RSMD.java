import java.sql.*;
public class RSMD {
    public static void main(String[] args) throws Exception{
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "ashwin");

            String query="Select *from "+args[0];
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            ResultSetMetaData rsmd=rs.getMetaData();
            System.out.println("Name of a Table="+args[0]);

            int c=rsmd.getColumnCount();
            for(int i=1;i<=c;i++){
                System.out.println(rsmd.getColumnName(i)+"\t");
            }
            while (rs.next()) {
                for(int i=1;i<=c;i++){
                    System.out.println(rs.getString(i)+"\t");
                }
            }
            con.close();
        } catch (Exception e) {
            
        }
        
    }
}
