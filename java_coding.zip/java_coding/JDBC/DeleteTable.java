import java.sql.*;
public class DeleteTable {
    public static void main(String[] args) throws Exception {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","ashwin");
            
            Statement stmt=con.createStatement();
            stmt.execute("Drop Table student");
            con.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}

