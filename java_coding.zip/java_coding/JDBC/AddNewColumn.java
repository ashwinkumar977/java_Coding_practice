import java.sql.*;

public class AddNewColumn {
    public static void main(String[] args) throws Exception {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","ashwin");
            
            Statement stmt=con.createStatement();
            stmt.execute("Alter table student add(Email_id varchar(30))");
            System.out.println("Added new Column Successfully.....");
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
