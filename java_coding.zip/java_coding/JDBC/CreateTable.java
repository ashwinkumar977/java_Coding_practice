import java.sql.*;
public class CreateTable {

    public static void main(String[] args){
        Connection con=null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","ashwin");
            if(con!=null){
                System.out.println("Connection Successfull...");
            }
            else {
                System.out.println("Error");
            }
            Statement stmt=con.createStatement();
            stmt.execute("Create Table student(Roll number(5),Name varchar(20),Course varchar(10))");
            System.out.println("Table Created");
            con.close();
        } catch (Exception e) {
            e.getStackTrace();
        }

    }
}
