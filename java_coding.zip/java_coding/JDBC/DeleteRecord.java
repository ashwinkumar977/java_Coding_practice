import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteRecord {
    public static void main(String[] args) {
        String ans = "no";
        try (Scanner sc = new Scanner(System.in)) {
            // Register the JDBC driver and establish connection to database
            Class.forName("oracle.jdbc.driver.OracleDriver");
            try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "ashwin");
                 PreparedStatement stmt = con.prepareStatement("INSERT INTO student (Roll, Name, Course) VALUES (?, ?, ?)")) {

                while (true) {
                    System.out.println("Enter roll number of Student");
                    int r = sc.nextInt();
                    System.out.println("Enter Name of a Student");
                    String n = sc.next();
                    System.out.println("Enter Course of a Student");
                    String c = sc.next();
                    System.out.println("Enter your Email_id");
                    String e=sc.next();

                    // Set the values for the PreparedStatement
                    stmt.setInt(1, r);
                    stmt.setString(2, n);
                    stmt.setString(3, c);
                    stmt.setString(4, e);

                    // Execute the update
                    stmt.executeUpdate();
                    System.out.println("Deleted Successfully...");

                    // Ask the user if they want to insert more records
                    System.out.println("Do you want to delete any more record? YES/NO");
                    ans = sc.next();
                    if (ans.equalsIgnoreCase("NO")) {
                        break;
                    }
                }
            } catch (SQLException e) {
                System.out.println("SQL error: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
