import java.sql.*;

public class DeleteColumn {
    public static void main(String[] args) throws Exception {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","ashwin");
            
            Statement stmt=con.createStatement();
            stmt.execute("Alter Table student drop(Email_id)");
            System.out.println("Deleted Column Successfully........");
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
