class Divide1{
    public static void main(String[] args) {
        try{
            int a=Integer.parseInt(args[0]);
            int b=Integer.parseInt(args[1]);
            System.out.println("Result after division="+a/b);
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("attempt to access invalid array index number");

        }
        catch(ArithmeticException e){
            System.out.println("second number must not be zero");
        }
        catch(NumberFormatException e){
            System.out.println("please pass numberic  String");
        }
    }
}