/**
 * DivideFirst
 */
public class DivideFirst {
    public static void main(String[] args) {
        try{
            if(args.length <2){
                ArrayIndexOutOfBoundsException e=new ArrayIndexOutOfBoundsException();
                throw(e);
            }
            int a=Integer.parseInt(args[0]);
            int b=Integer.parseInt(args[1]);
            if(b==0){
                throw(new ArithmeticException("second number must not be zero"));
            }
            System.out.println("Result after division="+a/b);
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println(e);
        }
        catch(ArithmeticException e){
            System.out.println(e);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}