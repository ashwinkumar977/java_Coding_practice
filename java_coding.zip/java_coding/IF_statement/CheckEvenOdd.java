import java.util.Scanner;
class CheckEvenOdd
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any integer number");
       int n=sc.nextInt();
       if(n % 2==0)
         System.out.println(n +" is even number");
       if(n% 2!=0)
         System.out.println(n +" is odd number");
    }
}