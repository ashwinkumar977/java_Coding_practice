//to find largest number among three number
import java.util.Scanner;
class Largest
{
    public static void main(String arr[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any three number");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        double c=sc.nextDouble();
        double l=0;
        if(a>b && a>c)
           l=a;
        if(b>a && b>c)
          l=b;
        if(c>a && c>b)
          l=c;
        System.out.println(l + " is the largest number");
    }
}