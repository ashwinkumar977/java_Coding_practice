import java.applet.*;
import java.awt.*;
public class MyApplet1 extends Applet {
    public void init(){
        setBackground(new Color(220, 110, 235));
        setForeground(new Color(125, 190, 200));
        setFont(new Font("Times new Roman", Font.ITALIC, 20));
    }
    public void paint(Graphics g){
        g.drawString("Select RadioButton From", 20, 60);
        g.drawString("Applet2 to Change its background", 20, 80);
    }
}
