import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class MyApplet2 extends Applet implements ItemListener{
    MyApplet1 a1;
    Checkbox r1,r2,r3,r4;
    public void init(){
        CheckboxGroup g=new CheckboxGroup();
        r1=new Checkbox("RED",g,true);
        r2=new Checkbox("GREEN",g,false);
        r3=new Checkbox("YELLO",g,false);
        r4=new Checkbox("CYAN",g,false);
        add(r1);
        add(r2);
        add(r3);
        add(r4);
        r1.addItemListener(this);
        r2.addItemListener(this);
        r3.addItemListener(this);
        r4.addItemListener(this);
        AppletContext ctx=getAppletContext();
        a1=(MyApplet1)ctx.getApplet("one");
    }
    public void itemStateChanged(ItemEvent e){
        if(r1.getState()){
            a1.setBackground(Color.RED);
        }
        else if(r2.getState()){
            a1.setBackground(Color.GREEN);
        }
        else if(r3.getState()){
            a1.setBackground(Color.YELLOW);
        }
        else if(r4.getState()){
            a1.setBackground(Color.CYAN);
        }
    }

}
