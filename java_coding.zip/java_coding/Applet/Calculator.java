import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator extends Applet implements ActionListener{
    static TextField txt1,txt2,txt3;
    static double a,b,r;
    public void init(){
        setBackground(Color.RED);
        setForeground(Color.GRAY);
        setFont(new Font("Arial",Font.ITALIC, 25));
        Label lb1=new Label("Enter 1st Number");
        Label lb2=new Label("Enter 2nd Number");
        Label lb3=new Label("Result");
        txt1=new TextField(10);
        txt2=new TextField(10);
        txt3=new TextField(10);
        Button b1=new Button("Sum");
        Button b2=new Button("Sub");
        Button b3=new Button("Mul");
        Button b4=new Button("Div");
        Button b5=new Button("Rem");
        Button b6=new Button("Close");
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(3, 2));
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        p1.add(lb3);
        p1.add(txt3);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(1, 6));
        p2.add(b1);
        p2.add(b2);
        p2.add(b3);
        p2.add(b4);
        p2.add(b5);
        p2.add(b6);
        add(p1);
        add(p2);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        a=Double.parseDouble(txt1.getText());
        b=Double.parseDouble(txt2.getText());
        if(s.equals("Sum")){
            r=a+b;
            txt3.setText(String.valueOf(r));
        }
        else if(s.equals("Sub")){
            r=a-b;
            txt3.setText(String.valueOf(r));
        }
        else if(s.equals("Mul")){
            r=a*b;
            txt3.setText(String.valueOf(r));
        }
        else if(s.equals("Div")){
            r=a/b;
            txt3.setText(String.valueOf(r));
        }
        else if(s.equals("Rem")){
            r=a%b;
            txt3.setText(String.valueOf(r));
        }
        else if(s.equals("Close")){
            System.exit(0 );
        }
    }
}
