import java.awt.*;
import java.applet.*;
public class WelcomeMsg extends Applet {
    public void init(){
        setBackground(Color.RED);
        setForeground(Color.GREEN);
        setFont(new Font("Arial", Font.BOLD, 20));
    }
    public void paint(Graphics g){
        g.drawString("Welcome", 30, 50);
    }  
}