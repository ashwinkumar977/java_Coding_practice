import java.applet.Applet;
import java.awt.Graphics;

public class Flag extends Applet {

    public void paint(Graphics g){
        g.drawRect(100, 30, 150, 40);
        g.drawRect(100,70 , 150, 40);
        g.drawRect(100, 110, 150, 40);
        g.drawLine(100, 110, 100, 450);
        g.drawLine(95, 30, 95, 450);
        g.drawRect(60, 450, 80, 30);
        g.drawRect(40,480 , 120, 30);
        g.drawRect(20, 510, 160, 30);
        g.drawOval(155, 70, 40, 40);
    }  
}
