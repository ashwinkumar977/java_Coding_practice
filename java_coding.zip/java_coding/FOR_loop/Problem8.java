/*  1-2+3-4+5=3  */
public class Problem8 {
    public static void main(String[] args) {
        int sum=0;
        for(int i=1;i<=5;i++){
            if(i%2==0){
                System.out.print(i+"+");
                sum=sum-i;
            }
            else{
                System.out.print(i+"-");
                sum=sum+i;
            }
        }
        System.out.println("\b="+sum);
    }
    
}

