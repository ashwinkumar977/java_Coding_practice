/*  0+1+1+2+3+5+8+13+...........n        */
import java.util.Scanner;
public class Problem13 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int a=0,b=1,s=0;
        while (s<=n) {
            System.out.print(s+"+");
            a=b;
            b=s;
            s=a+b;

        }
        System.out.println("\b .............");
        sc.close();
    }
}
