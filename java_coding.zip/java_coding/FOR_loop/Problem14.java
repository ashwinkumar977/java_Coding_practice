/* 1,2,5,12,29,70.........n    */
import java.util.Scanner;
public class Problem14 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int a=0,b=1;
        while(a<=n){
            System.out.print(b);
            a=b;


        }
        sc.close();

    }
    
}
