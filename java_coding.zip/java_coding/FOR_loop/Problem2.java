/*  2+4+6+8+.................20   */
public class Problem2 {
    public static void main(String[] args) {
        int sum=0;
        for(int i=2;i<=20;i++){
            sum=sum+i;
        }
        System.out.println("total="+sum);
    }
    
}
