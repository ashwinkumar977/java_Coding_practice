class Problem1
{
    public static void main(String[] args) {
        int s=0;
        for(int i=1;i<=10;i++){
            s=s+i;
        }
        System.out.println("total sum ="+s);
    }
}