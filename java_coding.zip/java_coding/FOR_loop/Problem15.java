/*  x - x^2 + x^3 - x^4 + x^5 */
/**
 * Problem15
 */
public class Problem15 {

    public static void main(String[] args) {
        for(int i=1;i<=5;i++){
            if(i%2==0){
                System.out.print("x^"+i+" + ");
            }
            else{
                System.out.print("x^"+i+" - ");
            }
        }
    }
}