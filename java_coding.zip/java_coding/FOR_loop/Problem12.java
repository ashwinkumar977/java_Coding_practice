import java.util.Scanner;
public class Problem12 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int c=1;
        for(int i=0;i<=n;i++){
            int t=c;
            System.out.print(t+",");
            c+=i+1;
        }
        sc.close();

    }
    
}

