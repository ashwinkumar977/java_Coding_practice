/*  19+17+15+.........1  */
public class Problem3 {
    public static void main(String[] args) {
        int sum=0;
        for(int i=19;i>=1;i--){
            sum=sum+i;
        }
        System.out.println("total="+sum);
    }
    
}
