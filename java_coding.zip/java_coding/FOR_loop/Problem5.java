public class Problem5 {
    public static void main(String[] args) {
        int s=0;
        for(int i=1;i<=10;i++){
            s=s+(i*i*i);
        }
        System.out.println("total sum ="+s);
    }
}
    
