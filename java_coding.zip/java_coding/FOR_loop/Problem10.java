import java.util.Scanner;
public class Problem10{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int s=0;
        for(int i=1;i<=n;i=i*10){
            s=s+i;
            if(s<n){
                System.out.print(s+"+");
            }
            else{
                System.out.print(s);
            }
        }
        sc.close();
        
    }
    
}
