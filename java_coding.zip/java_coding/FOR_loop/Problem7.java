public class Problem7{
    public static void main(String[] args) {
        int s=0;
        for(int i=1;i<=10;i++){
            s=s+i;
            if(i<10){
                System.out.print(i+"+");
            }
            else{
                System.out.print(i);
            }
            
        }
        System.out.print("="+s);
    }
}
    
