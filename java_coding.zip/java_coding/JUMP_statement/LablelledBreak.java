// example of labelled Break jump statement
class labelledBreak{
    public static void main(String[] args){
        outer :for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                if(i==3){
                    System.out.print("i understand the use of break of labelled break");
                    break outer;
                }
                System.out.print("*");
            }
            System.out.println();
        }
    }
}