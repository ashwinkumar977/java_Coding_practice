/*example of labelled continue  */
public class LabelledContinue {
    public static void main(String[] args) {
        outer: for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                if(i==2||i==4){
                    System.out.print("i understand the use of labelled continue");
                    continue outer;
                }
                System.out.print('*');
            }
            System.out.println();
        }
    }
    
}
