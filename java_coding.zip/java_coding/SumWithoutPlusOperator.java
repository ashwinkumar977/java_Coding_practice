//to sum of 1st and last digit of four digit number
import java.util.Scanner;
class SumWithoutPlusOperator
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any two number");
       int a=sc.nextInt();
       int b=sc.nextInt();
       int sum=a-(-b);
       System.out.println("sum of 1st and last digit of input number="+sum);
       sc.close();
   }
}