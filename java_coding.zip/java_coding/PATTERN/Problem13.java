/**
 * Problem13
 *      1
 *      0 1
 *      0 1 0
 *      1 0 1 0
 *      1 0 1 0 1
 */
public class Problem13 {
    public static void main(String[] args) {
        int c=1;
        for( int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                if(c%2==0){
                    System.out.print(0);
                }            
                else{
                    System.out.print(1);

                }
                c++;
            }
            System.out.println();
        }
    }
}

