import java.util.Scanner;
class nestedif
{
    public static void main(String a[])
    {
        Scanner sc =new Scanner(System.in);
        int r,m; String st;
        System.out.println("enter roll and marks");
        r=sc.nextInt();
        m=sc.nextInt();
        if(r>=1 && r<=120)
        {
            if(m>300)
               st="pass";
            else
               st="fail";
            System.out.println(st);
        }
        else
            System.out.println("roll is incorrect");
        sc.close();    
    }
}
