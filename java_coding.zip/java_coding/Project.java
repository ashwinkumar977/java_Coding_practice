public class Project {

    public static void main(String[] args) {
        int n1,n2,n3,num;
        public read()
    }
}

