/**
 * to create a menu based program such as
 * press1, for factorial
 * press2, to check input number is perfect number or not
 * press3, to check input number is strong number or not
 * press4 ,to exit
 */
import java.util.Scanner;
public class MenuBasedProblem1 {   
     public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int ch;
        do{
            System.out.println("press1 , for factorial");
            System.out.println("press2, to check perfect number");
            System.out.println("press3, to check strong number");
            System.out.println("press4,t0 exit");
            System.out.println("enter any above valid choice");
            ch=sc.nextInt();
            if(ch==1){
                System.out.println("enter any number");
                int n=sc.nextInt();
                int f=1;
                while(n>1){
                    f=f*n;
                    n--;
                }
                System.out.println("factorial="+f);
            }
            else if(ch==2){
                System.out.println("enter any number");
                int n=sc.nextInt();
                int s=0,i=1;
                while (i<=n/2) {
                    if(n%i==0){
                        s=s+i;
                    }
                    i++;
                }
                if(s==n){
                    System.out.println("input number is perfect number");
                }
                else{
                    System.out.println("input number is not perfect number");
                }
            }
            else if(ch==3){
                System.out.println("enter any number");
                int n=sc.nextInt();
                int r,f,s=0,n1=n;
                while (n>0) {
                    r=n%10;
                    f=1;
                    while (r>1) {
                        f=f*r;
                        r--;
                    }
                    s=s+f;
                    n=n/10;
                }
                if(n1==s){
                    System.out.println("input number is strong number");
                }
                else{
                    System.out.println("input number is not strong number");
                }
            }
            else if(ch==4){
                System.exit(0);
            }
            else{
                System.out.println("wrong choice");
            }
        }while(ch >=1 && ch <=4);
        sc.close();
    }
}