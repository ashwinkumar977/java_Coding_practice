import java.util.Scanner;
/**
 * to count number of digit in input number
 */
public class CountDigit {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any integer number");
        int n=sc.nextInt();
        int c=0;
        do{
            c++;
            n=n/10;
        }while(n>0);
        System.out.println("total digit of input number="+c);
        sc.close();
    }

    
}