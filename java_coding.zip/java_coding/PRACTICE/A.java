public class A{
        private void bca(){
              System.out.println("private method");
        }
}
