import java.util.Scanner;

class HandShake{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of man");
        int n=sc.nextInt();
        int max=n*(n-1)/2;
        System.out.println("maximam handshake of input number of man : "+max);
        sc.close();
    }
}