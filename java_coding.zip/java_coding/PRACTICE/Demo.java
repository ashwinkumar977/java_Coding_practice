class  Demo
	{
            /*   int a;
   		public static void main(String args[])
			{ 
                          Demo obj=new Demo();   //creating class object
                           obj.a=15;
            	          System.out.println(obj.a);
   			}   */

          /*
               static int a;    //instance variable
   		public static void main(String args[])
			{ 
                  
                           Demo.a=20;   // static variable can be access using class_name.variable
            	          System.out.println(Demo.a);
   			}
                              */


  /*
   		public static void main(String args[])
			{ 
                          float a=15.5f;
                          int b=10;
            	   System.out.println(a<b);//it given true because result does not assign in any value varible
   			}       */


public static void main(String args[])
			{ 
                          float f=12.5f;
                          int b=int(f);
            	          System.out.println(b);
}
	}