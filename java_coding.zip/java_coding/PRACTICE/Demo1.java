class Demo1{
   int a=90;
   public void bca(int a){
       int a=60;
       System.out.println(a);
       System.out.println(a);
    }
 
   public static void main(String args[]){
       Demo1 obj=new Demo1();
       obj.bca(5);
      
   }
}   