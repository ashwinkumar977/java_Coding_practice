import java.util.Scanner;

public class Tairs {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("input number of tairs");
        int n=sc.nextInt();
        int a=0,b=1;
        for(int i=2;i<n;i++){
            int sum=a+b;
            a=b;
            b=sum;
            System.out.println("Maximum ways to go : "+b);
        }
        sc.close();
    }
}
