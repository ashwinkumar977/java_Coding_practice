class Abc
{
   static{
                        System.out.println("Hey Brother");
                    }
}