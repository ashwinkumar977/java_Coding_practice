class A{
        private void bca(){
              System.out.println("private method");
        }
}
class B{
        public static void main(String args[]){
               A obj=new A();
               obj.bca();
        }
}