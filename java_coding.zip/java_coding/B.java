import PRACTICE;
class B{
        public static void main(String args[]){
               A obj=new A();
               obj.bca();
        }
}