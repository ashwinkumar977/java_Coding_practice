//to calculate distance between two points
import java.util.Scanner;
class DistanceTwoPoints
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(String arr[])
       System.out.println("Enter 1st points");
       int x1=sc.nextInt();
       int y1=sc.nextInt();
       System.out.Println("Enter 2nd points");
       int x2=sc.nextInt();
       int y2=sc.nextInt();
       double d=Math.sqrt((x2-x1)*(x2-x1)-(y2-y1)*(y2-y1));
       System.out.println("distance between two points="+d);
   }
}
       