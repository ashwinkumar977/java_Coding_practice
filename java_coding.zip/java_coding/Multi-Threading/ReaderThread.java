public class ReaderThread extends Thread {
    Buffer b;
    public ReaderThread(Buffer b){
        this.b=b;
    }
    public void run(){
        System.out.println("Reader Thread is Started");
        for(int i=1;i<=10;i++){
            b.read();
        }
    }
}
