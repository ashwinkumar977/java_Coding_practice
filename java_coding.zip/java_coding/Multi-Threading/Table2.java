public class Table2 {
    public static void main(String[] args) {
        System.out.println("Main Thread is Started to display of Table of 2");
        System.out.println("Creating & Starting Table5 Thread");
        Table5 t=new Table5();
        t.start();
        for(int i=1;i<=10;i++){
            System.out.print(2*i+"\t");
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        System.out.println("Main Thread is terminated");
    }
}
