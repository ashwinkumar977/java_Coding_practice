/* Example of interrupting a Thread */
public class LazyThread extends Thread {
    public void run(){
        System.out.println("Ah.! , someone has Started me");
        System.out.println("Don't disturb , going to Sleep");
        try {
            Thread.sleep(8000);
            System.out.println("Feeling Freash After 8 sec Sleeping ");
        } catch (Exception e) {
            System.out.println("I am Disturb");
        }
    }
}