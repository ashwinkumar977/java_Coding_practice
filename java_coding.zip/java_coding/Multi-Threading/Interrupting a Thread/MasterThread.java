/* Example of Interrupting a Thread */
public class MasterThread {
    public static void main(String[] args) {
        System.out.println("Execution of master Thread is Started");
        System.out.println("Creating and Staring Execution of LazyThread ");
        LazyThread lt=new LazyThread();
        lt.start();
        lt.join(1000);
        if(lt.isAlive()){
            System.out.println("LazyThread is taking to time of execution so it is Interrupted");
            lt.interrupt();
        }
    }
}
