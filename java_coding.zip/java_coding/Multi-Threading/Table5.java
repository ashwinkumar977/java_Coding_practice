public class Table5 extends Thread {
    public void run(){
        System.out.println("Table5 Thread is Started");
        for(int i=1;i<=10;i++){
            System.out.println(5*i);
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        System.out.println("Table5 Thread is Terminated");
    }
}
