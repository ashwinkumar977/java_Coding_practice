public class WriterThread extends Thread{
    Buffer b;
    public WriterThread(Buffer b){
       this.b=b;
    }
    public void run(){
        System.out.println("Writer thread is Started");
        for(int i=1;i<=10;i++){
            b.write(i);
        }
    }
}
