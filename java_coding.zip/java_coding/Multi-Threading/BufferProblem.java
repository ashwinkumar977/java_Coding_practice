public class BufferProblem {
    int x;
    boolean written=false;
    public synchronized void write(int a){
        if(written){
            System.out.println("WriterThread enters into moniter out of turn so it is Suspended");
            try {
                wait();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        x=a;
        System.out.println(a+" is Written");
        written=true;
        notify();
    }
    public synchronized void read(){
        if(!written){
            System.out.println("ReaderThread enters into a Moniter out of turn so it is Suspended");
            try {
                wait();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        System.out.println(x+" is read");
        written=false;
        notify();
    }
}
