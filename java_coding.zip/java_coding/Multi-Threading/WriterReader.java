public class WriterReader {
    public static void main(String[] args) {
        Buffer b=new Buffer();
        System.out.println("Creating and Starting Writer and Reader Thread");
        WriterThread w=new WriterThread(b);
        ReaderThread r=new ReaderThread(b);
        w.start();
        r.start();
    }
}
