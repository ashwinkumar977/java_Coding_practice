public class Buffer {
    int x;
    public synchronized void write(int a){
        x=a;
    }
    public synchronized void read(){
        System.out.println(x+" is Read");
    }
}
