import java.lang.Thread;
public class ThreadDemo {

    public static void main(String[] args) {
        Thread t=Thread.currentThread(); 
        String name=t.getName();
        int priority=t.getPriority();
        System.out.println("Name of a Thread="+name);
        System.out.println("Priority of a thread="+priority);

        System.out.println("Suspending execution of a Thread for 5 second");
        try {
            Thread.sleep(5000);
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("Execution of a Thread is Required After 5 Second");
        t.setName("MyThread");
        t.setPriority(7);
        System.out.println("Name & Priority of a Thread After Change");
        System.out.println("Name="+t.getName());
        System.out.println("Priority="+t.getPriority());
    }
}