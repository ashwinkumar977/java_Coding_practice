/**
 * A
 */
public class A {

    public static void main(String[] args) {
        int k=0;
        for(int i=1;i<=7;i++){
            for(int j=6;j>=i;j--){
                System.out.print(' ');
            }
            System.out.print('*');
            for(int j=1;j<k;j++){
                if(i==4){
                    System.out.print('*');
                }
                else{
                    System.out.print(' ');
                }
            }
            k=k+2;
            if(i!=1){
                System.out.print('*');
            }
            System.out.println();
        }
    }
}