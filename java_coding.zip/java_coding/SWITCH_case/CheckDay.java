/* cap to input number of day of a week and display name on of days on the basis of number of days */
import java.util.Scanner;
public class CheckDay {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number of day of a week");
        int n=sc.nextInt();
        switch (n) {
            case 0: System.out.println("SUNDAY");break;
            case 1:System.out.println("MONDAY");break;
            case 2:System.out.println("TUESDAY");break;
            case 3:System.out.println("WEDNESSDAY");break;
            case 4:System.out.println("THURSDAY");break;
            case 5:System.out.println("FRIDAY");break;
            case 6:System.out.println("SATUARDAY");break;
            default:System.out.println("INVALID CHOICE");break;
        }
        sc.close();
    }
    
}
