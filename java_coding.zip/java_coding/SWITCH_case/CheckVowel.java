/* cap to check input alphabet is vowel or consonent using switch...case statement */
import java.util.Scanner;
/**
 * CheckVowel
 */
public class CheckVowel {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any alphabet character");
        char c=sc.next().charAt(0);
        switch (c) {
            case 'a':
            case 'A':
            case 'e':
            case 'E':
            case 'i':
            case 'I':
            case 'o':
            case 'O':
            case 'u':
            case 'U':
                System.out.println(c+" is vowel");
                break;
            default:
                System.out.println(c+" is consonent");
                break;
        }
        sc.close();
    }
}