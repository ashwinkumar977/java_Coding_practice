/*
 *      Problem6
 *               2
 *             3 4
 *           4 5 6 
 *         5 6 7 8
 *       6 7 8 9 10
 */
public class Problem6 {
    public static void main(String arr[]){
        for(int i=1 ;i<=5;i++){
            for(int k=4;k>=i;k--){
                System.out.print(' ');
            }
            for(int j=1;j<=i;j++){
                System.out.print(i+j);
            }
            System.out.println();
        }
    }
}