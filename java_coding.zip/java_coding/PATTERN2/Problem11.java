/*
           Problem8
 *                  5
 *                5 4 5
 *              5 4 3 4 5  
 *            5 4 3 2 3 4 5
 *          5 4 3 2 1 2 3 4 5
 */
public class Problem11 {
    public static void main(String[] args) {
        for(int i=5;i>=1;i--){
            for(int k=i-1;k>=1;k--){
                System.out.print(' ');
            }
            for(int j=5;j>=i;j--){
                System.out.print(j);
            }
            for(int j=i+1;j<=5;j++){
                System.out.print(j);
           }
            System.out.println();
        }
    }
}

