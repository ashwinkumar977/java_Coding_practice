/*
 *      Problem6
 *               1
 *             0 1
 *           0 1 0 
 *         1 0 1 0
 *       1 0 1 0 1
 */
public class Problem7 {
    public static void main(String arr[]){
        int c=1;
        for(int i=1 ;i<=5;i++){
            for(int k=4;k>=i;k--){
                System.out.print(' ');
            }
            for(int j=1;j<=i;j++){
                if(c%2==0){
                    System.out.print(0);
                }
                else{
                    System.out.print(1);
                }
                c++;
            }
            System.out.println();
        }
    }
}
