/*
 *   *                
    ***
   *****
    ***
   *****
  *******
   *****
  *******
 *********
  *******
 *********
***********
    ***
    ***
    ***
 */
public class Problem12 {
    public static void main(String[] args) {
        for(int i=1;i<=3;i++){
            for(int j=5;j>=i;j--){
                System.out.print(' ');
            }
            for(int j=1;j<=i*2-1;j++){
                System.out.print('*');
            }
            System.out.println();
        }
        for(int i=3;i<=5;i++){
            for(int j=6;j>=i;j--){
                System.out.print(' ');
            }
            for(int j=3;j<=i*2-1;j++){
                System.out.print('*');
            }
            System.out.println();
        }
        for(int i=5;i<=7;i++){
            for(int j=7;j>=i;j--){
                System.out.print(' ');
            }
            for(int j=5;j<=i*2-1;j++){
                System.out.print('*');
            }
            System.out.println();
        }
        for(int i=7;i<=9;i++){
            for(int j=8;j>=i;j--){
                System.out.print(' ');
            }
            for(int j=7;j<=i*2-1;j++){
                System.out.print('*');
            }
            System.out.println();
        }
        for(int i=1;i<=3;i++){
            for(int j=1;j<=4;j++){
                System.out.print(' ');
            }
            for(int j=1;j<=3;j++){
                System.out.print('*');
            }
            System.out.println();
        }
    }
    
}
