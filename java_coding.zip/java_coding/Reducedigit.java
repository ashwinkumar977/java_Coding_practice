//to sum of 1st and last digit of four digit number
import java.util.Scanner;
class SumFirstAndLastDigit
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any four digit number");
       int n=sc.nextInt();
       int sum=0;
       int r=n%10;
       n=n/10;
       sum=sum+r;
       r=n/100;
       sum=sum+r;
       System.out.println("sum of 1st and last digit of input number="+sum);
       sc.close();
   }
}