/*Example of array of Objects */
import java.util.Scanner;

class Student{
    int roll;
    String name,course;
    public Student(int a,String b,String c){
        roll=a;
        name=b;
        course=c;
    }
    public void display(){
        System.out.print("Roll="+roll);
        System.out.print("\t\tName="+name);
        System.out.print("\tCourse="+course);
        System.out.println();
    }
}

public class InputAndDisplay {  
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of objects");
        int n=sc.nextInt();
        Student s[]=new Student[n];
        s[0]=new Student(16, "Ashwin kumar","BCA");
        s[1]=new Student(34, "Rahul Kumar", "B.Sc");
        s[2]=new Student(53, "Gulshan kumar", "B.Com");
        System.out.println("contents of array of Object");
        for(int i=0;i<s.length;i++){
            s[i].display();
        }
        sc.close();
    } 
}