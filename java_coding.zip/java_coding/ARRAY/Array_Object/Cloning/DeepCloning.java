class A implements Cloneable{
    int x;
    public A(int a){
        x=a;
    }
    void display(){
        System.out.println("x="+x);
    }
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
    
class B implements Cloneable{
    A a;
    int y;
    public B(int p,int q){
        a=new A(p);
        y=q;
    }
    void display(){
        a.display();
        System.out.println("y="+y);
    }
    protected Object clone() throws CloneNotSupportedException{
        B t=(B)super.clone();
        t.a=(A)t.a.clone();
        return t;
    }
}
public class DeepCloning {
    public static void main(String[] args) {
        B d=new B(5, 6);
        System.out.println("displaying contents of Object");
        d.display();
        B t=(B)d.clone();
        System.out.println("contents of object after cloning");
        t.display();
        t.a.x=t.a.x+5;
        d.display();
        t.display();
    }
}

