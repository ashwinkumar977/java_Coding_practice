
class One  implements Cloneable{
    public int a,b;
    public One(int x,int y){
        a=x;
        b=y;
    }
    public void display(){
        System.out.println("a="+a);
        System.out.println("b="+b);
    }
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}

/**
 * CloneTest
 */
public class CloneTest {
    public static void main(String[] args) throws CloneNotSupportedException{
        One o=new One(5, 6);
        o.display();
        System.out.println("creating cloning of an objects o");
        One t=(One) o.clone();
        System.out.println("contents of objects after cloning");
        t.display();
        System.out.println(o==t);
        o.a=o.a+5;
        o.b=o.b+5;
        System.out.println("contents of objects o and t after cloning ");
        o.display();
        t.display();
    }
}