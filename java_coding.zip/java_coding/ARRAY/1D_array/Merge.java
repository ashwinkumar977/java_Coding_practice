import java.util.Scanner;

public class Merge {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1st 1d array");
        int n1=sc.nextInt();
        int a[]=new int[n1];
        System.out.println("input element in 1st 1d array");
        for(int i=0;i<n1;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("displaying all element of 1st 1d array are");
        for(int i=0;i<n1;i++){
            System.out.print(a[i]+"\t");
        }
        System.out.println("\nenter size of 2nd 1d array");
        int n2=sc.nextInt();
        int b[]=new int[n2];
        System.out.println("input element in 2nd 1d array");
        for(int i=0;i<n2;i++){
            b[i]=sc.nextInt();
        }
        sc.close();
        System.out.println("displaying all element of 2nd 1d array are");
        for(int i=0;i<n2;i++){
            System.out.print(b[i]+"\t");
        }
        int c[]=new int[n1+n2];
        int j=0;
        for(int i=0;i<n1;i++){
            c[j]=a[i];
            j++;
        }
        for(int i=0;i<n2;i++){
            c[j]=b[i];
            j++;
        }
        System.out.println("\ndisplay after mergeing");
        for(j=0;j<n1+n2;j++){
            System.out.print(c[j]+"\t");
        }
        sc.close();
    } 
}
