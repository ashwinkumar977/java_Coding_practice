import java.util.Scanner;

public class CountOccurance {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("displaying all elements of 1d array");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+"\t");
        }
        System.out.println("\n enter searching element");
        int s=sc.nextInt();
        int occurance=0;
        for(int i=0;i<n;i++){
            if(a[i]==s){
                occurance++;
            }
        }
        if(occurance==0){
            System.out.println("searching element is not found");
        }
        else{
            System.out.println("number of occurance of searching element="+occurance);
        }
        sc.close();
    }
}
