import java.util.Scanner;

public class Copy {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        //for(int i=0;i<n;i++){
        for(int i=0;i<a.length;i++){
   
            a[i]=sc.nextInt();
        }
        int b[]=new int[n];
        for(int i=0;i<n;i++){
            b[i]=a[i];
        }
        System.out.println("displaying all element  after copying of 1d array are");
        for(int i=0;i<n;i++){
            System.out.println(b[i]);
        }
        sc.close();
    }
}
