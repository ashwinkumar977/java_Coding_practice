import java.util.Scanner;

public class Sort {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("displaying all element of 1d array are");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+"\t");
        }
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(a[i]>a[j]){
                    int t=a[j];
                    a[j]=a[i];
                    a[i]=t;
                }
            }
        }
        System.out.println("displaying all element after sorting");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+"\t");
        }
        sc.close();
    }
}
