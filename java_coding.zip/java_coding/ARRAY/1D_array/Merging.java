import java.util.Scanner;
public class Merging {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of list1");
        int n1=sc.nextInt();
        int a[]=new int[n1];
        System.out.println("input elements in list1");
        for(int i=0;i<n1;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("enter size of list2");
        int n2=sc.nextInt();
        int b[]=new int[n2];
        System.out.println("input elements in list2");
        for(int i=0;i<n2;i++){
            b[i]=sc.nextInt();
        }
        int c[]=merge(a,b);
        System.out.println("list after merging");
        for(int i=0;i<c.length;i++){
            System.out.print(c[i]+"\t");
        }
    }
    static int[] merge(int a[],int b[]){
        int c[]=new int[a.length+b.length];
        int i=0,j=0,k=0;
        while (i<a.length && j<b.length) {
            if(a[i]<b[j]){
                c[k++]=a[i++];
            }
            else if(a[i]>b[j]){
                c[k++]=b[j++];
            }
            else{
                c[k++]=a[i++];
    
            }
        }
        while (i<a.length) {
            c[k++]=a[i++];
        }
        while (j<b.length) {
            c[k++]=b[i]++;
        }
        
    }

}
