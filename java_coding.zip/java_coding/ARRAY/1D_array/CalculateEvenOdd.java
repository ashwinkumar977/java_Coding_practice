import java.util.Scanner;

public class CalculateEvenOdd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int s=0,m=1;
        for(int i=0;i<n;i++){
            if(a[i] %2==0){
                s=s+a[i];
            }
            else{
                m=m*a[i];
            }
        }
        System.out.println("total sum of even number="+s);
        System.out.println("total multiplication of odd number="+m);
        sc.close();
    }

}
