import java.util.Scanner;
public class Largest {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int l=a[0];
        for(int i=0;i<n;i++){
            if(a[i]>l){
                l=a[i];
            }
        }
        System.out.println("largest number="+l);
        sc.close();
    } 

}
