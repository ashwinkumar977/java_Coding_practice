import java.util.Scanner;

public class Delete {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("displaying all element of 1d array are");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+"\t");
        }
        System.out.println("\ninput position of insert element");
        int pos=sc.nextInt();
        int b[]=new int[(n-1)];
        for(int i=0;i<n-1;i++){
            if(pos==i){
                b[i]=a[i+1];
            }
            else if(pos>i){
                b[i]=a[i];
            }
            else{
              b[i]=a[i+1];  
            }
        }
        for(int i=0;i<n-1;i++){
            System.out.print(b[i]+"\t");
        }
        sc.close();
    }
}
