import java.util.Scanner;
public class First {   
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("displaying all element of 1d array are");
        for(int i=0;i<n;i++){
            System.out.println(a[i]);
        }
        sc.close();
    } 
}