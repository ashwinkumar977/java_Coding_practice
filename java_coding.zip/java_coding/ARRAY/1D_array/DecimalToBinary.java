import java.util.Scanner;
public class DecimalToBinary {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any decimal number");
        int n=sc.nextInt();
        int lenth=0;
        int temp=n;
        while(temp>0){
            temp=temp/2;
            lenth++;
        }
        int bin[]=new int[lenth];
        for(int i=0;i<lenth;i++){
            bin[i]=n%2;
            n=n/2;
        }
        System.out.println("display in binary form");
        for(int i=lenth-1;i>=0;i--){
            System.out.print(bin[i]+"\t");
        }
        sc.close();
    }
}
