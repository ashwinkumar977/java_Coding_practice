import java.util.Scanner;
public class PositiveNegative {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int pos=0,neg=0;
        for(int i=0;i<n;i++){
            if(a[i] < 0){
                neg++;
                System.out.println(a[i]+"is negative number");
            }
            else{
                pos++;
                System.out.println(a[i]+"is positive number");
            }
        }
        System.out.println("total even number="+pos);
        System.out.println("total odd number="+neg);
        sc.close();
    } 
}


