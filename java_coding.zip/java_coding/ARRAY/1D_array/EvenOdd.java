import java.util.Scanner;
public class EvenOdd {   
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int even=0,odd=0;
        for(int i=0;i<n;i++){
            if(a[i] %2==0){
                even++;
                System.out.println(a[i]+"is even number");
            }
            else{
                odd++;
                System.out.println(a[i]+"is odd number");
            }
        }
        System.out.println("total even number="+even);
        System.out.println("total odd number="+odd);
        sc.close();
    } 
}
