import java.util.Scanner;

public class Smallest {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of 1d array");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("input element in 1d array");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int s=a[0];
        for(int i=0;i<n;i++){
            if(a[i]<s){
                s=a[i];
            }
        }
        System.out.println("smallest number="+s);
        sc.close();
    }
}
