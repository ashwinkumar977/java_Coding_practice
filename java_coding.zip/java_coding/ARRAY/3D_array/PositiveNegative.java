import java.util.Scanner;

public class PositiveNegative {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of 2d array, rows and columns 3d array");
        int n=sc.nextInt();
        int r=sc.nextInt();
        int c=sc.nextInt();
        int a[][][]=new int[n][r][c];
        System.out.println("input element in 3d array");
        for(int i=0;i<n;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<c;k++){
                    a[i][j][k]=sc.nextInt();
                }
            }
        }
        System.out.println("display elements of 3d array");
        for(int i=0;i<n;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<c;k++){
                    System.out.print(a[i][j][k]+"\t");
                }
                System.out.println();
            }
            System.out.println();
        }
        int pos=0,neg=0;
        for(int i=0;i<n;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<c;k++){
                    if(a[i][j][k] < 0){
                        neg++;
                        System.out.println(a[i][j][k]+"is Negative number");
                    }
                    else{
                        pos++;
                        System.out.println(a[i][j][k]+"is Positive number");
                    }
                }
            }
        }
        System.out.println("total Positive number="+pos);
        System.out.println("total Negative number="+neg);
        sc.close();
    }
}
