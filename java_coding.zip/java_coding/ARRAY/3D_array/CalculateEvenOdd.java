import java.util.Scanner;

public class CalculateEvenOdd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of 2d array, rows and columns 3d array");
        int n=sc.nextInt();
        int r=sc.nextInt();
        int c=sc.nextInt();
        int a[][][]=new int[n][r][c];
        System.out.println("input element in 3d array");
        for(int i=0;i<n;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<c;k++){
                    a[i][j][k]=sc.nextInt();
                }
            }
        }
        System.out.println("display elements of 3d array");
        for(int i=0;i<n;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<c;k++){
                    System.out.print(a[i][j][k]+"\t");
                }
                System.out.println();
            }
            System.out.println();
        }
        int s=0,m=1;
        for(int i=0;i<n;i++){
            for(int j=0;j<r;j++){
                for(int k=0;k<c;k++){
                    if(a[i][j][k] %2== 0){
                        s=s+a[i][j][k];  
                    }
                    else{
                        m=m*a[i][j][k];
                    }
                }
            }
        }
        System.out.println("total sum of even number="+s);
        System.out.println("total multiplicatin of odd number="+m);
        sc.close();
    }
}
