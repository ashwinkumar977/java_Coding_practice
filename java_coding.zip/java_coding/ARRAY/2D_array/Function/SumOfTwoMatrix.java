import java.util.Scanner;

public class SumOfTwoMatrix {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in){
            System.out.println("input no. of rows and columns");
            int r=sc.nextInt();
            int c=sc.nextInt();
            int a[][]=new int[r][c];
            int b[][]=new int[r][c];
            int c[][]=new int[r][c];
        
        }
    }
}
