/*to calculate sum of primary diagonal and secondary diagonal of a square matrix [3*3]  */
import java.util.Scanner;

public class SumDiagonal {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a[][]=new int[3][3];
        System.out.println("input elements in square  matrix [3*3]");
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                a[i][j]=sc.nextInt();
            }
        }
        System.out.println("displaying all elements are");
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        int pd=0,sd=0;
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                if(i==j){
                    pd=pd+a[i][j];
                }
                if(i+j==2){
                    sd=sd+a[i][j];
                }
            }
        }
        System.out.println("sum of primary diagonal="+pd);
        System.out.println("sum of secondary diagonal="+sd);
        sc.close();
    }
}
