/*to calculate sum all elements of  in row wise and column wise */
import java.util.Scanner;

public class SumRowColumnWise {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a[][]=new int[3][3];
        System.out.println("input elements in a sqaure matrix[3*3]");
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                a[i][j]=sc.nextInt();
            }
        }
        System.out.println("displaying all elements are");
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        int sr0=0,sr1=0,sr2=0;
        int sc0=0,sc1=0,sc2=0;
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                if(i==0){
                    sr0=sr0+a[i][j];
                }
                else if(i==1){
                    sr1=sr1+a[i][j];
                }
                else if(i==2){
                    sr2=sr2+a[i][j];
                }
                else if(j==0){
                    sc0=sc0+a[i][j];
                }
                else if(j==1){
                    sc1=sc1+a[i][j];
                }
                else if(j==2){
                    sc2=sc2+a[i][j];
                }
            }
        }
        System.out.println("displaying all elements are");
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                System.out.print(a[i][j]+"\t");
            }
            if(i==0){
                System.out.print("="+sr0);
            }
            else if(i==1){
                System.out.print("="+sr1);
            }
            else if(i==2){
                System.out.println("="+sr2);
            }
            System.out.println();
        }
        System.out.println("||\t||\t||");
        System.out.print(sc0+"\t"+sc1+"\t"+sc2);
        sc.close();
    }
}
