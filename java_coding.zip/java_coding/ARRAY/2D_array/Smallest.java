/*to find Smallest element in 2d array */
import java.util.Scanner;

public class Smallest {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of rows and columns of 2d array");
        int r=sc.nextInt();
        int c=sc.nextInt();
        int a[][]=new int[r][c];
        System.out.println("input elements in 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                a[i][j]=sc.nextInt();
            }
        }
        System.out.println("displaying all elements are");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        int s=a[0][0];
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(a[i][j] < s){
                    s=a[i][j];
                }
            }
        }
        System.out.println("Smallest element="+s);
        sc.close();
    }
}
