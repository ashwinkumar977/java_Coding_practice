/*to calculate sum even and multiplication of odd in 2d array element */
import java.util.Scanner;

public class CalculateEvenOdd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of rows and columns 2d array");
        int r=sc.nextInt();
        int c=sc.nextInt();
        int a[][]=new int[r][c];
        System.out.println("input element in 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                a[i][j]=sc.nextInt();
            }
        }
        System.out.println("display elements of 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        int s=0,m=1;
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(a[i][j] %2==0){
                    s=s+a[i][j];
                }
                else{
                    m=m*a[i][j];
                }
            }
        }
        System.out.println("total sum of even number="+s);
        System.out.println("total multiplication of odd number="+m);
        sc.close();
    }
}
