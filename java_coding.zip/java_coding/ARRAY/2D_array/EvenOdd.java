/* to check and count number of even and odd element in 2d array */
import java.util.Scanner;

public class EvenOdd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of rows and columns 2d array");
        int r=sc.nextInt();
        int c=sc.nextInt();
        int a[][]=new int[r][c];
        System.out.println("input element in 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                a[i][j]=sc.nextInt();
            }
        }
        System.out.println("display elements of 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        int even=0,odd=0;
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(a[i][j] %2== 0){
                    even++;
                    System.out.println(a[i][j]+"is even number");
                }
                else{
                    odd++;
                    System.out.println(a[i][j]+"is odd number");
                }
            }
        }
        System.out.println("total even number="+even);
        System.out.println("total odd number="+odd);
        sc.close();
    }
}
