/*to check and count positive and negative element in 2d array */
import java.util.Scanner;

public class CalculatePositiveNegative {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number of rows and columns 2d array");
        int r=sc.nextInt();
        int c=sc.nextInt();
        int a[][]=new int[r][c];
        System.out.println("input element in 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                a[i][j]=sc.nextInt();
            }
        }
        System.out.println("display elements of 2d array");
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                System.out.print(a[i][j]+"\t");
            }
            System.out.println();
        }
        int pos=0,neg=0;
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(a[i][j] < 0){
                    neg++;
                    System.out.println(a[i][j]+"is negative");
                }
                else{
                    pos++;
                    System.out.println(a[i][j]+"is positive");
                }
            }
        }
        System.out.println("total positive number="+pos);
        System.out.println("total negative number="+neg);
        sc.close();
    }
}
