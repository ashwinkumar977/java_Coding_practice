/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.*;  

public class conn{
    Connection c=null;
    Statement s;
    public conn(){  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");
            c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","ashwin");
            if(c!=null){
                System.out.println("Connection Successfull...");
            }
            else {
                System.out.println("Error");
            }
            s=c.createStatement(); 
            
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }  
}  

