/* to count and display spy number between 500 to 2000 */
/**
 * SpyNumber
 */
public class SpyNumber {

    public static void main(String[] args) {
        int count=0;
        for(int n=500;n<=2000;n++){
            int s=0,m=1,n1=n;
            while(n1>0){
                int r=n1%10;
                s=s+r;
                m=m*r;
                n1=n1/10;
            }
            if(s==m){
                count++;
                System.out.println(n+" is a spy number ");
            }
        }
        System.out.println("total number="+count);
    }
}