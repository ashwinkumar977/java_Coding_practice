/*   1!-2!+3!-4!+5!   */
public class Problem2 {
    public static void main(String[] args) {
        int s=0,sign=1;
        for(int i=1;i<=5;i++){
            int f=1,n=i;
            while(n>1){
                f=f*n;
                n--;
            }
            s=s+(f*sign);
            sign=sign*(-1);
        }
        System.out.println("result="+s);
    }
}
