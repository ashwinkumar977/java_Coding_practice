/* to display prime factor of input number */
import java.util.Scanner;
public class DisplayPrimeFacter {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        for(int i=2;n!=1;i++){
            while (n%i==0) {
                System.out.println(i);
                n=n/i;
            }
        }
        sc.close();
    }
    
}
