/*
 *   cap to display table from 1 to 15 using nested loop
 */
class Table1To15{
    public static void main(String[] args) {
        for(int i=1;i<=15;i++){
            int j=1;
            System.out.println("***********************************");
            System.out.println("table of "+i);
            while (j<=10) {
                System.out.println(i*j);
                j++;
            }
        }
    }
}