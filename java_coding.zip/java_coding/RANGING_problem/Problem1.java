/*   1!+2!+3!+4!+5!= ?   */
public class Problem1 {
    public static void main(String[] args) {
        int s=0;
        for(int i=1;i<=5;i++){
            int n=i,f=1;
            while (n>1) {
                f=f*n;
                n--;
            }
            s=s+f; 
        }
        System.out.println("sum="+s);
    }
}
