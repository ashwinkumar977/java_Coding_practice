/* to count and display armstrong number of 3 digit */
class CheckArmstrong {
    public static void main(String[] args) {
        int c=0;
        for(int n=100;n<=999;n++){
            int n1=n,sum=0;
            while (n1>0) {
                int r=n1%10;
                n1=n1/10;
                sum=sum+(r*r*r);
            }
            if(sum==n){
                c++;
                System.out.println(n+"is armstrong number");  
            }                             
        }
        System.out.println("total armstrong number between 100 to 999="+c);
    }
}