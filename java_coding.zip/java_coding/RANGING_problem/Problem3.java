/*
 *     problem3
 *     1       1
 *     12     21
 *     123   321
 *     1234 4321
 *     123454321
 */
public class Problem3 {
    public static void main(String[] args) {
        int k=7;
        for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j);
            }
            for(int j=1;j<=k;j++){
                System.out.print(' ');
            }
            k=k-2;
            for(int j=i;j>=1;j--){
                if(j==5){
                    continue;   
                }
                System.out.print(j);
            }
            System.out.println();
        }
    }    
}
