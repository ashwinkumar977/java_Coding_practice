/* to count and display strong number between 1 to 2000 */
public class StrongNumber {
    public static void main(String[] args) {
        int count=0;
        for(int n=1;n<=2000;n++){
            int s=0,n1=n;
            while (n1>0) {
                int r=n1%10;
                int f=1;
                while(r>1){
                    f=f*r;
                    r--;
                }
                s=s+f;
                n1=n1/10;
            }
            if(n==s){
                count++;
                System.out.println(n+" is strong number");
            }
        }
        System.out.println("total number="+count);
    }
}
