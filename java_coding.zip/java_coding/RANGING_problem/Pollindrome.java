/* to count and display all pollindrome number between 1 to 500 */
class PollindromeNumber {
    public static void main(String[] args) {
        int count=0;
        for(int n=1;n<=500;n++){
            int s=0,n1=n;
            while(n1!=0){
                int r=n1%10;
                s=s*10+r;
                n1=n1/10;
            }
            if(n==s){
                count++;
                System.out.println(n+"is a pollindrome number");
            }
        }
        System.out.println("total number="+count);
    }
}
