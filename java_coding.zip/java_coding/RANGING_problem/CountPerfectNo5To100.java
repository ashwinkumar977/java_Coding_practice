/*
 *  to count and display perfect number between 5 to 100
 */
class CountPerfectNo5To100 {
    public static void main(String[] args) {
        int c=0;
        for(int i=5;i<=100;i++){
            int s=0,j=1;
            while ( j<=i/2) {
                if(i%j==0){
                     s=s+j;
                }
                j++;
            }
            if(s==i){
                c++;
                System.out.println(i+"is perfect number");
            }
        }
        System.out.println(c);
    }
}