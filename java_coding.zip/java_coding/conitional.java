import java.util.Scanner;
class conditional
{
    public static void main(String a[])
    {
        Scanner sc =new Scanner(System.in);
        int num; String st;
        System.out.println("enter any number");
        num=sc.nextInt();
        st = (num %2==0) ? "even" : "odd";
        System.out.println(st);
        
        sc.close();    
    }
}