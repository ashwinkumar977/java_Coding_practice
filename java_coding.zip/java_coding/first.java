class First
{
    public static void main(String[] args) {
        System.out.print("MY NAME IS ASHWIN KUMAR");
    }
}