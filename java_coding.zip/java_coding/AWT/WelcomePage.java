import java.awt.*;
import java.awt.event.*;
public class WelcomePage extends Frame implements ActionListener {
    public static void main(String[] args) {
        WelcomePage wp=new WelcomePage();
        
        Label l1=new Label("Welcome to School Management System");
        Button b1=new Button("Continue");
        Toolkit.getDefaultToolkit().getImage("1716800243451.jpg");
        Button b2=new Button("Close");
        
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(1, 2));
        p1.add(b1);
        p1.add(b2);
        wp.setLayout(new FlowLayout());
        wp.add(l1);
        
        wp.add(p1);
        wp.setSize(300, 250);
        wp.setTitle("Welcome Page");
        wp.setVisible(true);
        b1.addActionListener(wp);
        b2.addActionListener(wp);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Continue")){
            
        }
        else if(s.equals("Close")){
            System.exit(0);
        }
    }
    
}
