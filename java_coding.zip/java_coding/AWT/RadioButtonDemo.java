import java.awt.*;
import java.awt.event.*;
public class RadioButtonDemo extends Frame implements ItemListener{
    static Checkbox rb1,rb2,rb3,rb4,rb5,rb6;
    public static void main(String[] args) {
        RadioButtonDemo rd=new RadioButtonDemo();
        CheckboxGroup g=new CheckboxGroup();
        rb1=new Checkbox("RED" ,g,true);
        rb2=new Checkbox("YELLOW" ,g,false);
        rb3=new Checkbox("PINK" ,g,false);
        rb4=new Checkbox("GREEN" ,g,false);
        rb5=new Checkbox("CYAN" ,g,false);
        rb6=new Checkbox("CLOSE" ,g,false);
        rd.setLayout(new FlowLayout());
        rd.add(rb1);
        rd.add(rb2);
        rd.add(rb3);
        rd.add(rb4);
        rd.add(rb5);
        rd.add(rb6);
        rd.setTitle("RadioButton Demo");
        rd.setSize(300, 300);
        rd.setVisible(true);
        rb1.addItemListener(rd);
        rb2.addItemListener(rd);
        rb3.addItemListener(rd);
        rb4.addItemListener(rd);
        rb5.addItemListener(rd);
        rb6.addItemListener(rd);
    }
    public void itemStateChanged(ItemEvent e){
        if(rb1.getState()){
            setBackground(Color.RED);
        }
        else if(rb2.getState()){
            setBackground(Color.YELLOW);
        }
        else if(rb3.getState()){
            setBackground(Color.PINK);
        }
        else if(rb4.getState()){
            setBackground(Color.GREEN);
        }
        else if(rb5.getState()){
            setBackground(Color.CYAN);
        }
        else if(rb6.getState()){
            System.exit(0);
        }
    }

}
