import java.awt.*;
import java.awt.event.*;
public class MyNotepad extends Frame implements ActionListener{
    static TextArea txt1;
    public static void main(String[] args) {
        MyNotepad mn=new MyNotepad();
        txt1=new TextArea(15,50);
        Button b1=new Button("Close");

        MenuBar mb=new MenuBar();
        Menu fileMenu=new Menu("File");
        Menu editMenu=new Menu("Edit");
        Menu formatMenu=new Menu("Format");
        Menu helpMenu=new Menu("Help");
        MenuItem newFileItem=new MenuItem("New");
        MenuItem openFileItem=new MenuItem("Open");
        MenuItem saveasFileItem=new MenuItem("Save as");
        MenuItem printFileItem=new MenuItem("Print");
        MenuItem exitFileItem=new MenuItem("Exit");

        MenuItem cutEditItem=new MenuItem("Cut");
        MenuItem copyEditItem=new MenuItem("Copy");
        MenuItem pasteEditItem=new MenuItem("Paste");
        MenuItem findEditItem=new MenuItem("Find");
        MenuItem replaceyEditItem=new MenuItem("Replace");
        MenuItem selectAllEditItem=new MenuItem("Select all");
        MenuItem gotoEditItem=new MenuItem("Goto");
        MenuItem deleteEditItem=new MenuItem("Delete");

        MenuItem dateTimeFormatItem=new MenuItem("Date & Time");
        MenuItem bkcolorFormatItem=new MenuItem("BackGround Color");
        MenuItem frcolorFormatItem=new MenuItem("ForeGround Color");

        MenuItem aboutMynotepadHelpItem=new MenuItem("About Mynotepad");
        
        fileMenu.add(newFileItem);
        fileMenu.add(openFileItem);
        fileMenu.add(printFileItem);
        fileMenu.add(saveasFileItem);
        fileMenu.add(exitFileItem);

        editMenu.add(cutEditItem);
        editMenu.add(copyEditItem);
        editMenu.add(pasteEditItem);
        editMenu.add(findEditItem);
        editMenu.add(replaceyEditItem);
        editMenu.add(gotoEditItem);
        editMenu.add(selectAllEditItem);
        editMenu.add(deleteEditItem);

        formatMenu.add(dateTimeFormatItem);
        formatMenu.add(bkcolorFormatItem);
        formatMenu.add(frcolorFormatItem);

        helpMenu.add(aboutMynotepadHelpItem);

        mb.add(fileMenu);
        mb.add(editMenu);
        mb.add(formatMenu);
        mb.add(helpMenu);

        mn.setTitle("MyNotepad");
        mn.setMenuBar(mb);
        mn.setLayout(new FlowLayout());
        mn.add(txt1,BorderLayout.CENTER);
        mn.add(b1,BorderLayout.SOUTH);
        mn.setVisible(true);
        mn.setSize(450,350);

       b1.addActionListener(mn);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Close")){
            System.exit(ABORT);
        }

    }
}
