import java.awt.*;
import java.awt.event.*;
public class RegForm extends Frame implements ActionListener{
    static TextField txt1,txt2,txt3,txt4,txt5,txt6;
    static Checkbox cb1,cb2;
    public static void main(String[] args) {
        RegForm rg=new RegForm();
        Label lb=new Label("Welcome to Registration Form");
        Label lb1=new Label("Name");
        Label lb2=new Label("Father's Name");
        Label lb3=new Label("Mother's Name");
        Label lb4=new Label("DOB");
        Label lb5=new Label("Gender");
        Label lb6=new Label("Address");
        Label lb7=new Label("Email id");
        Label lb8=new Label("Mob no.");
        Label lb9=new Label("Developed by Ashwin Kumar");
        txt1=new TextField(10);
        txt2=new TextField(10);
        txt3=new TextField(10);
        txt4=new TextField(10);
        txt5=new TextField(10);
        txt6=new TextField(10);
        Label lblst1=new Label("DD");
        List l1=new List();
        l1.add("1");
        l1.add("2");
        l1.add("3");
        l1.add("4");
        l1.add("5");
        l1.add("6");
        l1.add("7");
        l1.add("8");
        l1.add("9");
        l1.add("10");
        l1.add("11");
        l1.add("12");
        l1.add("13");
        l1.add("14");
        l1.add("15");
        l1.add("16");
        l1.add("17");
        l1.add("18");
        l1.add("19");
        l1.add("20");
        l1.add("21");
        l1.add("22");
        l1.add("23");
        l1.add("24");
        l1.add("25");
        l1.add("26");
        l1.add("27");
        l1.add("28");
        l1.add("29");
        l1.add("30");
        l1.add("31");
        Label lblst2=new Label("MM");
        List l2=new List();
        l2.add("1");
        l2.add("2");
        l2.add("3");
        l2.add("4");
        l2.add("5");
        l2.add("6");
        l2.add("7");
        l2.add("8");
        l2.add("9");
        l2.add("10");
        l2.add("11");
        l2.add("12");
        Label lblst3=new Label("yyyy");
        List l3=new List();
        l3.add("2001");
        l3.add("2002");
        l3.add("2003");
        l3.add("2004");
        l3.add("2005");
        l3.add("2006");
        l3.add("2007");
        l3.add("2008");
        l3.add("2009");
        l3.add("2010");
        CheckboxGroup g=new CheckboxGroup();
        cb1=new Checkbox("Male" ,g,true);
        cb2=new Checkbox("Female" ,g,false);
        Button b1=new Button("Save");
        Button b2=new Button("Edit");
        Button b3=new Button("Delete");
        Button b4=new Button("Search");
        Button b5=new Button("Clear");
        Button b6=new Button("Close");
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(3, 2));
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        p1.add(lb3);
        p1.add(txt3);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(1,7));
        p2.add(lb4);
        p2.add(l1);
        p2.add(lblst1);
        p2.add(l2);
        p2.add(lblst2);
        p2.add(l3);
        p2.add(lblst3);
        Panel p3=new Panel();
        p3.setLayout(new GridLayout(1, 3));
        p3.add(lb5);
        p3.add(cb1);
        p3.add(cb2);
        Panel p4=new Panel();
        p4.setLayout(new GridLayout(3, 2));
        p4.add(lb6);
        p4.add(txt4);
        p4.add(lb7);
        p4.add(txt5);
        p4.add(lb8);
        p4.add(txt6);
        Panel p5=new Panel();
        p5.setLayout(new GridLayout(1,6));
        p5.add(b1);
        p5.add(b2);
        p5.add(b3);
        p5.add(b4);
        p5.add(b5);
        p5.add(b6);
        rg.setLayout(new GridLayout(7,1));
        rg.add(lb);
        rg.add(p1);
        rg.add(p2);
        rg.add(p3);
        rg.add(p4);
        rg.add(p5);
        rg.add(lb9);
        rg.setTitle("Reg Form");
        rg.setSize(500, 700);
        rg.setVisible(true);
        b1.addActionListener(rg);
        b2.addActionListener(rg);;
        b3.addActionListener(rg);
        b4.addActionListener(rg);
        b5.addActionListener(rg);
        b6.addActionListener(rg);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Close")){
            System.exit(0);
        }
        else if(s.equals("Clear")){
            txt1.setText("");
            txt2.setText("");
            txt3.setText("");
            txt4.setText("");
            txt5.setText("");
            txt6.setText("");
        }
        else if(s.equals("Save")){
            
        }
        else if(s.equals("Edit")){
            
        }
        else if(s.equals("Search")){
            
        }
        else if(s.equals("Delete")){
            
        }
    }
}
