import java.awt.*;
import java.awt.event.*;
public class SumOfTwoNumber extends Frame implements ActionListener {
    static TextField txt1,txt2,txt3;
    public static void main(String[] args) {
        SumOfTwoNumber s=new SumOfTwoNumber();
        Label l1=new Label("enter 1st number");
        Label l2=new Label("enter 2nd number");
        Label l3=new Label("Result");
        Button b1=new Button("sum");
        Button b2=new Button("clear");
        Button b3=new Button("close");
        txt1=new TextField(10);
        txt2=new TextField(10);
        txt3=new TextField(10);
        s.setLayout(new FlowLayout());
        s.add(l1);
        s.add(txt1);
        s.add(l2);
        s.add(txt2);
        s.add(l3);
        s.add(txt3);
        s.add(b1);
        s.add(b2);
        s.add(b3);
        s.setTitle("Sum");
        s.setSize(300,250);
        s.setVisible(true);
        b1.addActionListener(s);
        b2.addActionListener(s);
        b3.addActionListener(s);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("sum")){
            double a=Double.parseDouble(txt1.getText());
            double b=Double.parseDouble(txt2.getText());
            double s1=a+b;
            txt3.setText(String.valueOf(s1));
        }
        else if(s.equals("clear")){
            txt1.setText("");
            txt2.setText("");
            txt3.setText("");
        }
        else if(s.equals("close")){
            System.exit(0);
        }
    }
}
