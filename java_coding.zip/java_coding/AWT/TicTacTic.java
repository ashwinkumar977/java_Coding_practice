import java.awt.*;
import java.awt.event.*;
public class TicTacTic extends Frame implements ActionListener{
    static Button b1,b2,b3,b4,b5,b6,b7,b8,b9;
    static Label lb2;
    int c=1;
    public static void main(String[] args) {
        TicTacTic t=new TicTacTic();
        Label lb1=new Label("Welcome to Tic Tac Tic Game");
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(3,3));
        b1=new Button("");
        b2=new Button("");
        b3=new Button("");
        b4=new Button("");
        b5=new Button("");
        b6=new Button("");
        b7=new Button("");
        b8=new Button("");
        b9=new Button("");
        p1.add(b1);
        p1.add(b2);
        p1.add(b3);
        p1.add(b4);
        p1.add(b5);
        p1.add(b6);
        p1.add(b7);
        p1.add(b8);
        p1.add(b9);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(2,2));
        lb2=new Label("Result");
        Label lb3=new Label("Developed by Ashwin Kumar");
        Button btn=new Button("Close");
        p2.add(lb2);
        p2.add(lb3);
        p2.add(btn);
        t.setLayout(new BorderLayout());
        t.add(lb1,BorderLayout.NORTH);
        t.add(p1,BorderLayout.CENTER);
        t.add(p2,BorderLayout.SOUTH);
        t.setTitle("Tic Tac Tic");
        t.setVisible(true);
        t.setSize(300, 250);
        int i=1;
        while ( i>=1 && i<=9) {
            b1.addActionListener(t);
            b2.addActionListener(t);
            b3.addActionListener(t);
            b4.addActionListener(t);
            b5.addActionListener(t);
            b6.addActionListener(t);
            b7.addActionListener(t);
            b8.addActionListener(t);
            b9.addActionListener(t);
            i++;
            
        }
        lb2.setText(String.valueOf(i));
        btn.addActionListener(t);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Close")){
            System.exit(0);
        }
        while (c>=1 && c<=9) {
            
            if(c % 2 == 0){
                c++;
                if(e.getSource()==b1){
                    b1.setLabel("0");
                    
                }
                else if(e.getSource()==b2){
                    b2.setLabel("0");
                    
                }
                else if(e.getSource()==b3){
                    b3.setLabel("0");
                    
                }
                else if(e.getSource()==b4){
                    b4.setLabel("0");
                    
                }
                else if(e.getSource()==b5){
                    b5.setLabel("0");
                    
                }
                else if(e.getSource()==b6){
                    b6.setLabel("0");
                    
                }
                else if(e.getSource()==b7){
                    b7.setLabel("0");
                    
                }
                else if(e.getSource()==b8){
                    b8.setLabel("0");
                    
                }
                else if(e.getSource()==b9){
                    b9.setLabel("0");
                    
                }
                lb2.setText(String.valueOf(c));
            }
            else{
                c++;
                if(e.getSource()==b1){
                    b1.setLabel("x");
                    
                }
                else if(e.getSource()==b2){
                    b2.setLabel("x");
                    
                }
                else if(e.getSource()==b3){
                    b3.setLabel("x");
                    
                }
                else if(e.getSource()==b4){
                    b4.setLabel("x");
                    
                }
                else if(e.getSource()==b5){
                    b5.setLabel("x");
                    
                }
                else if(e.getSource()==b6){
                    b6.setLabel("x");
                    
                }
                else if(e.getSource()==b7){
                    b7.setLabel("x");
                    
                }
                else if(e.getSource()==b8){
                    b8.setLabel("x");
                    
                }
                else if(e.getSource()==b9){
                    b9.setLabel("x");
                }
                
            }
            
        }

    }
}
