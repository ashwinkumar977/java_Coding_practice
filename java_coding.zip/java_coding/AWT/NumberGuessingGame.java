import java.awt.*;
import java.awt.event.*;
public class NumberGuessingGame extends Frame implements ActionListener {
    static TextField txt;
    static Label lb4,lb5;
    static int n=135;
    int c=1;
    public static void main(String[] args) {
        NumberGuessingGame ng=new NumberGuessingGame();
        Label lb1=new Label("Welcome to Number Guessing Game");
        Label lb2=new Label("enter any Number");
        txt=new TextField(5);
        Label lb3=new Label("Number of Attemps");
        lb4=new Label("0");
        Button b1=new Button("Submit");
        Button b2=new Button("Clear");
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(3, 3));
        p1.add(lb2);
        p1.add(txt);
        p1.add(b1);
        p1.add(b2);
        p1.add(lb3);
        p1.add(lb4);
        lb5=new Label("You Guessed a Number");
        Label lb6=new Label("Developed by Ashwin Kumar");
        Button b3=new Button("Close");
        Panel p2=new Panel();
        p2.add(lb5);
        p2.add(lb6);
        p2.add(b3);
        ng.add(lb1);
        ng.add(p1);
        ng.add(p2);
        ng.setLayout(new FlowLayout());
        ng.setTitle("Number Guessing Game");
        ng.setVisible(true);
        ng.setSize(400, 250);
        b1.addActionListener(ng);
        b2.addActionListener(ng);
        b3.addActionListener(ng);  
    }
    public void actionPerformed(ActionEvent e){
        
        String s=e.getActionCommand();
        int a=Integer.parseInt(txt.getText());
        lb4.setText(String.valueOf(c));
        if(s.equals("Submit")){
            c++;
            if(n==a){
                lb5.setText("You Win......!");
            }
            else if(a<n){
                lb5.setText("Try a Higher Number");
            }
            else if(a>n){
                lb5.setText("Try a Lower Number");
            }
        }
        else if(s.equals("Clear")){
            txt.setText("");
            lb5.setText("You guessed a Number");
        }
        else if(s.equals("Close")){
            System.exit(0);
        }
    }
    
}
