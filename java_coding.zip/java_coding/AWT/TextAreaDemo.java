import java.awt.*;
import java.awt.event.*;
public class TextAreaDemo extends Frame implements ActionListener{
    static TextField txt1,txt2;
    static TextArea txt3;
    
    public static void main(String[] args) {
        TextAreaDemo td=new TextAreaDemo();
        txt3=new TextArea(10,50);
        txt1 =new TextField(10);
        txt2=new TextField(10);
        Label lb1=new Label("Find What->");
        Label lb2=new Label("Replace With->");
        Button b1=new Button("Find");
        Button b2=new Button("Replace");
        Button b3=new Button("Clear");
        Button b4=new Button("Close");
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(2,2));
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(1, 4));
        p2.add(b1);
        p2.add(b2);
        p2.add(b3);
        p2.add(b4);
        td.setLayout(new FlowLayout());
        td.add(p1,BorderLayout.NORTH);
        td.add(txt3,BorderLayout.CENTER);
        
        td.add(p2,BorderLayout.SOUTH);
        td.setTitle("Text Area Demo");
        td.setVisible(true);
        td.setSize(500, 300);
        b1.addActionListener(td);
        b2.addActionListener(td);
        b3.addActionListener(td);
        b4.addActionListener(td);  
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Find")){
            String s1=txt3.getText();
            String s2=txt1.getText();
            int si=s1.indexOf(s2);
            int li=si+s2.length();
            txt3.select(si, li);
        }
        else if(s.equals("Replace")){
            String s1=txt3.getText();
            String s2=txt1.getText();
            String s3=txt2.getText();
            txt3.select(s1.indexOf(s2),(s1+s2).length());
            txt3.replaceRange(s3, txt2.getSelectionStart(),txt2.getSelectionEnd());
        }
        else if(s.equals("Clear")){
            txt1.setText("");
            txt2.setText("");
        }
        else if(s.equals("Close")){
            System.exit(0);
        }
    }
}
