import java.awt.*;
import java.awt.event.*;

public class Calculator1 extends Frame implements ActionListener {
    static TextField txt;
    double a, b, r;
    String op;

    public static void main(String[] args) {
        Calculator1 c = new Calculator1();
        Panel p1 = new Panel();
        p1.setLayout(new FlowLayout());
        txt = new TextField(20);
        Button btn = new Button("ON/OFF");
        p1.add(txt);
        p1.add(btn);
        c.setLayout(new BorderLayout());
        c.add(p1, BorderLayout.NORTH);
        Panel p2 = new Panel();
        p2.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;

        Button[] buttons = {
            new Button("9"), new Button("8"), new Button("7"), new Button("6"),
            new Button("5"), new Button("4"), new Button("3"), new Button("2"),
            new Button("1"), new Button("0"), new Button("."), new Button("="),
            new Button("+"), new Button("-"), new Button("*"), new Button("/"),
            new Button("%"), new Button("sqrt"), new Button("n!"), new Button("pow"),
            new Button("cs"), new Button("log"), new Button("exp"), new Button("Clear")
        };

        for (int i = 0; i < buttons.length; i++) {
            gbc.gridx = i % 4;
            gbc.gridy = i / 4;
            p2.add(buttons[i], gbc);
            buttons[i].addActionListener(c);
        }

        c.add(p2, BorderLayout.CENTER);
        Label lb1 = new Label("Developed by Ashwin Kumar");
        c.add(lb1, BorderLayout.SOUTH);
        c.setTitle("Calculator");
        c.setVisible(true);
        c.setSize(300, 275);
    }

    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        if (s.matches("[0-9.]")) {
            concate(s);
        } else if (s.matches("[+\\-*/%]") || s.equals("pow")) {
            a = Double.parseDouble(txt.getText());
            txt.setText("");
            op = s;
        } else if (s.equals("=")) {
            b = Double.parseDouble(txt.getText());
            switch (op) {
                case "+" -> r = a + b;
                case "-" -> r = a - b;
                case "/" -> r = a / b;
                case "*" -> r = a * b;
                case "%" -> r = a % b;
                case "pow" -> r = Math.pow(a, b);
            }
            txt.setText(String.valueOf(r));
        } else if (s.equals("sqrt")) {
            a = Double.parseDouble(txt.getText());
            txt.setText(String.valueOf(Math.sqrt(a)));
        } else if (s.equals("log")) {
            a = Double.parseDouble(txt.getText());
            txt.setText(String.valueOf(Math.log(a)));
        } else if (s.equals("exp")) {
            a = Double.parseDouble(txt.getText());
            txt.setText(String.valueOf(Math.exp(a)));
        } else if (s.equals("Clear")) {
            txt.setText("");
        } else if (s.equals("n!")) {
            int n = Integer.parseInt(txt.getText());
            int f = 1;
            while (n > 0) {
                f *= n--;
            }
            txt.setText(String.valueOf(f));
        } else if (s.equals("cs")) {
            String s1 = txt.getText();
            StringBuffer s2 = new StringBuffer(s1);
            s2 = s2.deleteCharAt(s2.length() - 1);
            s1 = s2.toString();
            txt.setText(s1);
        }
    }

    public void concate(String s) {
        if (txt.getText().equals("0")) {
            txt.setText("");
        }
        String s1 = txt.getText().concat(s);
        txt.setText(s1);
    }
}

