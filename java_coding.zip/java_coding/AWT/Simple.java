import java.util.Scanner;
public class Simple{
    public static void main(String []arg){
        Scanner sc=new Scanner(System.in);
        System.out.println("input any number");
        int n=sc.nextInt();
        int i=0;
        int[] arr=new int[5];
        while (n!=0) {
            int r=n%10;
            arr[i]=r;
            n=n/10;
        }
        for(i=0;i<5;i++){
            for(int j=i+1;j<=5;j++){
                if(arr[i]>arr[j]){
                    arr[j]=arr[i];
                    arr[i]=arr[i+1]
                    
                }
                
            }
        }
        sc.close();
    }
}
