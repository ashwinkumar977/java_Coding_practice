import java.awt.*;
import java.awt.event.*;
class SchoolMenu extends Frame implements ActionListener{
    public static void main(String[] args) {
        SchoolMenu sm=new SchoolMenu();
        MenuBar mb=new MenuBar();
        Menu studentMenu=new Menu("Student");
        Menu teacherMenu=new Menu("Teacher");
        Menu facilityMenu=new Menu("Facility");
        Menu helpMenu=new Menu("Help");
        MenuItem newRegStudentItem=new MenuItem("New Reg");
        MenuItem newAdmStudentItem=new MenuItem("New Adm");
        MenuItem reportStudentItem=new MenuItem("Report");
        MenuItem exitStudentItem=new MenuItem("Exit");

        MenuItem newRegTeacherItem=new MenuItem("New Reg");
        MenuItem salaryTeacherItem=new MenuItem("Salary");

        MenuItem resultFacilityItem=new MenuItem("Result");
        MenuItem reportFacilityItem=new MenuItem("Report");
        MenuItem gameFacilityItem=new MenuItem("Game");
        MenuItem schlorshipFacilitytItem=new MenuItem("Schlorship");

        MenuItem aboutSchoolHelpItem=new MenuItem("About School");
        
        studentMenu.add(newRegStudentItem);
        studentMenu.add(newAdmStudentItem);
        studentMenu.add(reportStudentItem);
        studentMenu.add(exitStudentItem);

        teacherMenu.add(newRegTeacherItem);
        teacherMenu.add(salaryTeacherItem);

        facilityMenu.add(resultFacilityItem);
        facilityMenu.add(reportFacilityItem);
        facilityMenu.add(gameFacilityItem);
        facilityMenu.add(schlorshipFacilitytItem);

        helpMenu.add(aboutSchoolHelpItem);

        mb.add(studentMenu);
        mb.add(teacherMenu);
        mb.add(facilityMenu);
        mb.add(helpMenu);

        sm.setTitle("School Menu");
        sm.setMenuBar(mb);
        sm.setLayout(new FlowLayout());
        sm.setVisible(true);
        sm.setSize(300,400);

    }
    public void actionPerformed(ActionEvent e){

    }
}