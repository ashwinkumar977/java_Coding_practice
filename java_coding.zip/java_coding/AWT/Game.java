import java.awt.*;
import java.awt.event.*;
public class Game extends Frame implements ActionListener{
    static Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16;
    static Label lb3;
    int c=0;
    public static void main(String[] args) {
        Game  g=new Game();
        Label lb1=new Label("Welcome to Number Game");
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(4,4));
        b1=new Button("8");
        b2=new Button("14");
        b3=new Button("1");
        b4=new Button("12");
        b5=new Button("13");
        b6=new Button("9");
        b7=new Button("15");
        b8=new Button("2");
        b9=new Button("7");
        b10=new Button("3");
        b11=new Button("6");
        b12=new Button("11");
        b13=new Button("4");
        b14=new Button("5");
        b15=new Button("10");
        b16=new Button("");
        p1.add(b1);
        p1.add(b2);
        p1.add(b3);
        p1.add(b4);
        p1.add(b5);
        p1.add(b6);
        p1.add(b7);
        p1.add(b8);
        p1.add(b9);
        p1.add(b10);
        p1.add(b11);
        p1.add(b12);
        p1.add(b13);
        p1.add(b14);
        p1.add(b15);
        p1.add(b16);
        Panel p2=new Panel();
        p2.setLayout(new  GridLayout(2,2));
        Label lb2=new Label("No. of Attempts:-");
        lb3=new Label("0");
        Label lb4=new Label("Developed by Ashwin Kumar");
        Button btn=new Button("Close");
        p2.add(lb2);
        p2.add(lb3);
        p2.add(lb4);
        p2.add(btn);
        g.setLayout(new BorderLayout());
        g.add(lb1,BorderLayout.NORTH);
        g.add(p1,BorderLayout.CENTER);
        g.add(p2,BorderLayout.SOUTH);
        g.setTitle("Game");
        g.setSize(400,350);
        g.setVisible(true);
        b1.addActionListener(g);
        b2.addActionListener(g);
        b3.addActionListener(g);
        b4.addActionListener(g);
        b5.addActionListener(g);
        b6.addActionListener(g);
        b7.addActionListener(g);
        b8.addActionListener(g);
        b9.addActionListener(g);
        b10.addActionListener(g);
        b11.addActionListener(g);
        b12.addActionListener(g);
        b13.addActionListener(g);
        b14.addActionListener(g);
        b15.addActionListener(g);
        b16.addActionListener(g);
        btn.addActionListener(g);
    }
    public void actionPerformed(ActionEvent e){
        c++;
        String s=e.getActionCommand();
        lb3.setText(String.valueOf(c));
        if(s.equals("Close")){
            System.exit(0);
        }
        /*Button 1 */
        if(e.getSource()==b1){
            if(b2.getLabel().equals("")){
                b2.setLabel(b1.getLabel());
                b1.setLabel("");
            }
            else if(b5.getLabel().equals("")){
                b5.setLabel(b1.getLabel());
                b1.setLabel("");
            }
        }
        //Button 2
        else if(e.getSource()==b2){
            if(b1.getLabel().equals("")){
                b1.setLabel(b2.getLabel());
                b2.setLabel("");
            }
            else if(b3.getLabel().equals("")){
                b3.setLabel(b2.getLabel());
                b2.setLabel("");
            }
            else if(b6.getLabel().equals("")){
                b6.setLabel(b2.getLabel());
                b2.setLabel("");
            }
        }
        //Button 3
        else if(e.getSource()==b3){
            if(b2.getLabel().equals("")){
                b2.setLabel(b3.getLabel());
                b3.setLabel("");
            }
            else if(b4.getLabel().equals("")){
                b4.setLabel(b3.getLabel());
                b3.setLabel("");
            }
            else if(b7.getLabel().equals("")){
                b7.setLabel(b3.getLabel());
                b3.setLabel("");
            }
        }
        // Button 4
        else if(e.getSource()==b4){
            if(b3.getLabel().equals("")){
                b3.setLabel(b4.getLabel());
                b4.setLabel("");
            }
            else if(b8.getLabel().equals("")){
                b8.setLabel(b4.getLabel());
                b4.setLabel("");
            }
        }
        //Button 5
        else if(e.getSource()==b5){
            if(b1.getLabel().equals("")){
                b1.setLabel(b5.getLabel());
                b5.setLabel("");
            }
            else if(b6.getLabel().equals("")){
                b6.setLabel(b5.getLabel());
                b5.setLabel("");
            }
            else if(b9.getLabel().equals("")){
                b9.setLabel(b5.getLabel());
                b5.setLabel("");
            } 
        }
        //Button 6
        else if(e.getSource()==b6){
            if(b5.getLabel().equals("")){
                b5.setLabel(b6.getLabel());
                b6.setLabel("");
            }
            else if(b2.getLabel().equals("")){
                b2.setLabel(b6.getLabel());
                b6.setLabel("");
            }
            else if(b7.getLabel().equals("")){
                b7.setLabel(b6.getLabel());
                b6.setLabel("");
            }
            else if(b10.getLabel().equals("")){
                b10.setLabel(b6.getLabel());
                b6.setLabel("");
            } 
        }
        //Button 7
        else if(e.getSource()==b7){
            if(b3.getLabel().equals("")){
                b3.setLabel(b7.getLabel());
                b7.setLabel("");
            }
            else if(b6.getLabel().equals("")){
                b6.setLabel(b7.getLabel());
                b7.setLabel("");
            }
            else if(b8.getLabel().equals("")){
                b8.setLabel(b7.getLabel());
                b7.setLabel("");
            }
            else if(b11.getLabel().equals("")){
                b11.setLabel(b7.getLabel());
                b7.setLabel("");
            }
            
        }
        //Button 8
        else if(e.getSource()==b8){
            if(b7.getLabel().equals("")){
                b7.setLabel(b8.getLabel());
                b8.setLabel("");
            }
            else if(b4.getLabel().equals("")){
                b4.setLabel(b8.getLabel());
                b8.setLabel("");
            }
            else if(b12.getLabel().equals("")){
                b12.setLabel(b8.getLabel());
                b8.setLabel("");
            }
            
        }
        //Button 9
        else if(e.getSource()==b9){
            if(b5.getLabel().equals("")){
                b5.setLabel(b9.getLabel());
                b9.setLabel("");
            }
            else if(b10.getLabel().equals("")){
                b10.setLabel(b9.getLabel());
                b9.setLabel("");
            }
            else if(b13.getLabel().equals("")){
                b13.setLabel(b9.getLabel());
                b9.setLabel("");
            }  
        }
        //Button 10
        else if(e.getSource()==b10){
            if(b9.getLabel().equals("")){
                b9.setLabel(b10.getLabel());
                b10.setLabel("");
            }
            else if(b6.getLabel().equals("")){
                b6.setLabel(b10.getLabel());
                b10.setLabel("");
            }
            else if(b14.getLabel().equals("")){
                b14.setLabel(b10.getLabel());
                b10.setLabel("");
            }
            else if(b11.getLabel().equals("")){
                b11.setLabel(b10.getLabel());
                b10.setLabel("");
            }
        }
        //Button 11
        else if(e.getSource()==b11){
            if(b10.getLabel().equals("")){
                b10.setLabel(b11.getLabel());
                b11.setLabel("");
            }
            else if(b12.getLabel().equals("")){
                b12.setLabel(b11.getLabel());
                b11.setLabel("");
            }
            else if(b15.getLabel().equals("")){
                b15.setLabel(b11.getLabel());
                b11.setLabel("");
            }
            else if(b7.getLabel().equals("")){
                b7.setLabel(b11.getLabel());
                b11.setLabel("");
            }
            
        }
        //Button 12
        else if(e.getSource()==b12){
            if(b11.getLabel().equals("")){
                b11.setLabel(b12.getLabel());
                b12.setLabel("");
            }
            else if(b8.getLabel().equals("")){
                b8.setLabel(b12.getLabel());
                b12.setLabel("");
            }
            else if(b16.getLabel().equals("")){
                b16.setLabel(b12.getLabel());
                b12.setLabel("");
            }
            
        }
        //Button 13
        else if(e.getSource()==b13){
            if(b14.getLabel().equals("")){
                b14.setLabel(b13.getLabel());
                b13.setLabel("");
            }
            else if(b9.getLabel().equals("")){
                b9.setLabel(b13.getLabel());
                b13.setLabel("");
            }
        }
        //Button 14
        else if(e.getSource()==b14){
            if(b13.getLabel().equals("")){
                b13.setLabel(b14.getLabel());
                b14.setLabel("");
            }
            else if(b10.getLabel().equals("")){
                b10.setLabel(b14.getLabel());
                b14.setLabel("");
            }
            else if(b15.getLabel().equals("")){
                b15.setLabel(b14.getLabel());
                b14.setLabel("");
            }
            
        }
        //Button 15
        else if(e.getSource()==b15){
            if(b14.getLabel().equals("")){
                b14.setLabel(b15.getLabel());
                b15.setLabel("");
            }
            else if(b11.getLabel().equals("")){
                b11.setLabel(b15.getLabel());
                b15.setLabel("");
            }
            else if(b16.getLabel().equals("")){
                b16.setLabel(b15.getLabel());
                b15.setLabel("");
            }
            
        }
        // Button 16
        else if(e.getSource()==b16){
            if(b15.getLabel().equals("")){
                b15.setLabel(b16.getLabel());
                b16.setLabel("");
            }
            else if(b12.getLabel().equals("")){
                b12.setLabel(b16.getLabel());
                b16.setLabel("");
            }
        }
    }
}
