import java.awt.*;
import java.awt.event.*;
public class FocusDemo extends Frame implements FocusListener{
    static TextField txt1,txt2;
    public static void main(String[] args) {
        FocusDemo fd=new FocusDemo();
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(3, 2));
        Label lb1=new Label("Massage1");
        Label lb2=new Label("Massage2");
        txt1=new TextField(10);
        txt2=new TextField(10);
        Button b1=new Button("Gain");
        Button b2=new Button("Lose");
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        p1.add(b1);
        p1.add(b2);
        fd.setLayout(new FlowLayout());
        fd.add(p1);
        fd.setSize(300, 250);
        fd.setTitle("FocusDemo");
        fd.setVisible(true);
        //MyListner ml=new MyListner();
        //fd.addWindowListener(ml);
        
    }
    public void focusGained(FocusEvent e){
        txt1.setText("Button1 gets a focus");
        txt2.setText("Button2 loses a focus");
    }
    public void focusLost(FocusEvent e){
        txt2.setText("Button2 getss a focus");
        txt1.setText("Button1 loses a focus");

    }
    public class MyListner extends WindowAdapter{
        public void windowClosing(WindowEvent e){
            System.exit(ABORT);
        }
    }
    
    
}
