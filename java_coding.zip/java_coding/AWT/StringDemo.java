import java.awt.*;
import java.awt.event.*;
public class StringDemo extends Frame implements ActionListener {
    static TextField txt1,txt2;
    public static void main(String[] args) {
        StringDemo s=new StringDemo();
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(2, 2));
        Label lb1=new Label("Enter any String");
        Label lb2=new Label("Result");
        txt1 =new TextField(20);
        txt2=new TextField(20);
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(3, 2));
        Button b1=new Button("Length");
        Button b2=new Button("Uppercase");
        Button b3=new Button("Lowercase");
        Button b4=new Button("Reverse");
        Button b5=new Button("Clear");
        Button b6=new Button("Close");
        p2.add(b1);
        p2.add(b2);
        p2.add(b3);
        p2.add(b4);
        p2.add(b5);
        p2.add(b6);
        s.setLayout(new FlowLayout());
        s.add(p1);
        s.add(p2);
        s.setSize(500, 200);
        s.setTitle("String Demo");
        s.setVisible(true);
        b1.addActionListener(s);
        b2.addActionListener(s);;
        b3.addActionListener(s);
        b4.addActionListener(s);
        b5.addActionListener(s);
        b6.addActionListener(s);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Length")){
            int n=txt1.getText().length();
            txt2.setText(String.valueOf(n));
        }
        else if(s.equals("Uppercase")){
            String str=txt1.getText().toUpperCase();
            txt2.setText(str);
        }
        else if(s.equals("Lowercase")){
            String str=txt1.getText().toLowerCase();
            txt2.setText(str);
        }
        else if(s.equals("Reverse")){
            StringBuffer str=new StringBuffer(txt1.getText());
            str=str.reverse();
            txt2.setText(str.toString());
        }
        else if(s.equals("Clear")){
            txt1.setText("");
            txt2.setText("");
        }
        else if(s.equals("Close")){
            System.exit(0);
            
        }
    }
    
}
