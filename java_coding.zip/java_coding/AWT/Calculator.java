import java.awt.*;
import java.awt.event.*;
public class Calculator extends Frame implements ActionListener,ItemListener {

    static TextField txt1,txt2,txt3;
    static Checkbox cb1,cb2,cb3,cb4;
    double a,b,r;
    public static void main(String[] args) {
        Calculator c=new Calculator();
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(3, 2));
        Label lb1=new Label("Enter 1st Number");
        txt1=new TextField(10);
        Label lb2=new Label("Enter 2nd Number");
        txt2=new TextField(10);
        Label lb3=new Label("Result");
        txt3=new TextField(10);
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        p1.add(lb3);
        p1.add(txt3);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(2,2));
        CheckboxGroup g=new CheckboxGroup();
        cb1=new Checkbox("Sum" ,g,true);
        cb2=new Checkbox("Sub" ,g,false);
        cb3=new Checkbox("Mul" ,g,false);
        cb4=new Checkbox("Div" ,g,false);
        p2.add(cb1);
        p2.add(cb2);
        p2.add(cb3);
        p2.add(cb4);
        Panel p3=new Panel();
        p3.setLayout(new GridLayout(1, 3));
        Button b1=new Button("Ok");
        Button b2=new Button("Clear");
        Button b3=new Button("Close");
        p3.add(b1);
        p3.add(b2);
        p3.add(b3);
        c.setLayout(new FlowLayout());
        c.add(p1);
        c.add(p2);
        c.add(p3);
        c.setTitle("Calcultor");
        c.setSize(300, 250);
        c.setVisible(true);
        cb1.addItemListener(c);
        cb2.addItemListener(c);
        cb3.addItemListener(c);
        cb4.addItemListener(c);
        b1.addActionListener(c);
        b2.addActionListener(c);
        b3.addActionListener(c);
    }
    public void itemStateChanged(ItemEvent e){
        a=Double.parseDouble(txt1.getText());
        b=Double.parseDouble(txt2.getText());
        if(cb1.getState()){
            r=a+b;
        }
        else if(cb2.getState()){
            r=a-b;
        }
        else if(cb3.getState()){
            r=a*b;
        }
        else if(cb4.getState()){
            r=a/b;
        }
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Ok")){
            txt3.setText(String.valueOf(r));
        }
        else if(s.equals("Clear")){
            txt1.setText("");
            txt2.setText("");
            txt3.setText("");
        }
        else if(s.equals("Close")){
            System.exit(0);
        }
    }
}