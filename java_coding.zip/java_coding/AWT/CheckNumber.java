import java.awt.*;
import java.awt.event.*;
public class CheckNumber extends Frame implements ActionListener {
    static TextField txt1,txt2;
    public static void main(String[] args) {
        CheckNumber chk=new CheckNumber();
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(2, 2));
        Label lb1=new Label("Enter any Number");
        Label lb2=new Label("Result");
        txt1=new TextField(10);
        txt2=new TextField(20);
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(3, 2));
        Button b1=new Button("Factorial");
        Button b2=new Button("Check Prime");
        Button b3=new Button("Check Perfect");
        Button b4=new Button("Check Pollindrome");
        Button b5=new Button("Clear");
        Button b6=new Button("Close");
        p2.add(b1);
        p2.add(b2);
        p2.add(b3);
        p2.add(b4);
        p2.add(b5);
        p2.add(b6);
        chk.setLayout(new FlowLayout());
        chk.add(p1);
        chk.add(p2);
        chk.setTitle("Check Number");
        chk.setSize(400, 250);
        chk.setVisible(true);
        b1.addActionListener(chk);
        b2.addActionListener(chk);
        b3.addActionListener(chk);
        b4.addActionListener(chk);
        b5.addActionListener(chk);
        b6.addActionListener(chk);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Factorial")){
            int n = Integer.parseInt(txt1.getText());
            int f = 1;
            while (n > 0) {
                f *= n--;
            }
            txt2.setText(String.valueOf(f));
        }
        else if(s.equals("Check Prime")){
            int n = Integer.parseInt(txt1.getText());
            int i=2,flag=0;
            while(i<n/2){
                if(n%i==0){
                    flag=1;
                }
                i++;
            }
            if(flag==0){
                txt2.setText("Prime Number");
            }
            else{
                txt2.setText("Not Prime Number");
            }
        }
        else if(s.equals("Check Perfect")){
            int n = Integer.parseInt(txt1.getText());
            int n1=n,sum=0,i=1;
            while ( i<=n/2) {
                if(n%i==0){
                    sum=sum+i;
                }
                i++;
            }
            if(sum==n1){
                txt2.setText("Perfect Number");
            }
            else{
                txt2.setText("Not Perfect Number");
            }    
        }
        else if(s.equals("Check Pollindrome")){
            int n = Integer.parseInt(txt1.getText());
            int r,n1=n,rv=0;
            while (n>0) {
                r=n%10;
                rv=rv*10+r;
                n=n/10;
            }
            if(rv==n1){
                txt2.setText("Pollindrome Number");
            }
            else{
                txt2.setText(" not Pollindrome Number");
            }
        }
        else if(s.equals("Clear")){
            txt1.setText("");
            txt2.setText("");
            
        }
        else if(s.equals("Close")){
            System.exit(0);
        }
    }
    
}
