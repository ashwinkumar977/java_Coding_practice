import java.awt.*;
import java.awt.event.*;
public class LoginPage extends Frame implements ActionListener{
    static TextField txt1,txt2;
    public static void main(String[] args) {
        LoginPage lp=new LoginPage();
        Label lb=new Label("Welcome in Login Page");
        Label lb1=new Label("Enter your username");
        Label lb2=new Label("Enter your Password");
        txt1=new TextField(10);
        txt2=new TextField(10);
        Panel p1=new Panel();
        p1.setLayout(new GridLayout(2, 2));
        p1.add(lb1);
        p1.add(txt1);
        p1.add(lb2);
        p1.add(txt2);
        Button b1=new Button("login");
        Button b2=new Button("Clear");
        Button b3=new Button("Close");
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(1, 3));
        p2.add(b1);
        p2.add(b2);
        p2.add(b3);
        lp.setLayout(new FlowLayout());
        lp.add(lb);
        lp.add(p1);
        lp.add(p2);
        lp.setSize(400, 300);
        lp.setTitle("Login Page");
        lp.setVisible(true);
        b1.addActionListener(lp);
        b2.addActionListener(lp);
        b3.addActionListener(lp);
    }
    public void actionPerformed(ActionEvent e){
        String s=e.getActionCommand();
        if(s.equals("Clear")){
            txt1.setText("");
            txt2.setText("");
        }
        else if(s.equals("Close")){
            System.exit(ABORT);
        }
        else if(s.equals("Login")){
            
        }
    }
    
}
