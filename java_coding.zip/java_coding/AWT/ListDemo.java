import java.awt.*;
import  java.awt.event.*;
public class ListDemo extends Frame implements ItemListener{
    static TextField txt;
    static List l1,l2;
    public static void main(String[] args) {
        ListDemo ld=new ListDemo();
        Label lb1=new Label("Enter any Text");
        Label lb2=new Label("Background color");
        Label lb3=new Label("Foreground color");
        txt=new TextField(30);
        l1=new List(20);
        l2=new List(20);
        l1.add("RED");
        l1.add("GREEN");
        l1.add("YELLOW");
        l1.add("CYAN");
        l2.add("RED");
        l2.add("GREEN");
        l2.add("YELLOW");
        l2.add("CYAN");
        ld.setLayout(new BorderLayout());
        Panel p1=new Panel();
        p1.setLayout(new FlowLayout());
        p1.add(lb1);
        p1.add(txt);
        Panel p2=new Panel();
        p2.setLayout(new GridLayout(2,3));
        p2.add(lb2);
        p2.add(lb3);
        p2.add(l1);
        p2.add(l2);
        ld.add(p1,BorderLayout.NORTH);
        ld.add(p2,BorderLayout.CENTER);
        ld.setTitle("List Demo");
        ld.setSize(300, 275);
        ld.setVisible(true);
        l1.addItemListener(ld);
        l2.addItemListener(ld);
    }
    public void itemStateChanged(ItemEvent e){
        int n=l1.getSelectedIndex();
        if(n==0){
            txt.setBackground(Color.RED);
        }
        else if(n==1){
            txt.setBackground(Color.GREEN);
        }
        else if(n==2){
            txt.setBackground(Color.YELLOW);
        }
        else if(n==3){
            txt.setBackground(Color.CYAN);
        }
        int n1=l2.getSelectedIndex();
        if(n1==0){
            txt.setForeground(Color.RED);
        }
        else if(n1==1){
            txt.setForeground(Color.GREEN);
        }
        else if(n1==2){
            txt.setForeground(Color.YELLOW);
        }
        else if(n1==3){
            txt.setForeground(Color.CYAN);
        }
    } 
}
