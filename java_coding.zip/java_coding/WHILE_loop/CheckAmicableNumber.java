import java.util.Scanner;
class CheckAmicableNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any two number to check amiicable number");
        int n1=sc.nextInt();
        int n2=sc.nextInt();
        int x=n1,s1=0;
        int i=1;
        while (i<=n1/2) {
            if(n1%i==0){
                s1=s1+i;
            }
            i++;
        }
        int y=n2,s2=0;
        int j=1;
        while (j<=n2/2) {
            if(n2%j==0){
                s2=s2+j;
            }
            j++;
        }
        if(s1==y && s2==x){
            System.out.println("input both number is amicable number ");
        }
        else{
            System.out.println("input both number is not amicable number");
        }
        sc.close();
    }
}
