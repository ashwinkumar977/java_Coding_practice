/*to calculate sum of input 1st and last digit of a number*/
import java.util.Scanner;
class SumFirstLast
{
    public static void main(String arr[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any integer number");
        int n=sc.nextInt();
        int lastdigit=n%10;
        while(n>9){
            n=n/10;
        }
        int firstdigit=n;
        int sum=firstdigit + lastdigit;
        System.out.println("sumn of 1st and last digit="+sum);
        sc.close();
    }
}