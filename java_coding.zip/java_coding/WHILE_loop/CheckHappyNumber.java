/*
 * to check input number is happy number or not
 */
import java.util.Scanner;
public class CheckHappyNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int r,sum=0;
        while(n>0){
            r=n%10;
            sum=sum+r*r;
            n=n/10;
        }
        System.out.println(sum);
        sc.close();
    }  
}
