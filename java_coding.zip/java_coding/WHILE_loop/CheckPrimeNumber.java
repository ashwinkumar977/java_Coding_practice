/*
 * to check input number is prime nuber or not
 */
import java.util.Scanner;
public class CheckPrimeNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int i=2,flag=0;
        while(i<n/2){
            if(n%i==0){
                flag=1;
            }
            i++;
        }
        if(flag==1){
                System.out.println("input number is not prime number");
        }
        else{
                System.out.println("input number is prime number");
        }
        sc.close();
    }
}
