import java.util.Scanner;
class CheckPerfectSquareNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int i=1,n1=n,flag=0;
        while (i<=n/2) {
            if(n%i==0){
                int r=i;
                if(r*r==n1){
                    flag=1;
                }
                i++;
            }
            i++;
        }
        if(flag==1){
            System.out.println("input number is perfect square number");
        }
        else{
            System.out.println("input number is not perfect square number");
        }
        sc.close();
    }
}
    

