import java.util.Scanner;
class CheckPerfectNumber {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("enter any number");
        int n= sc.nextInt();
        int n1=n,sum=0,i=1;
        while ( i<=n/2) {
            if(n%i==0){
                sum=sum+i;
            }
            i++;
        }
        if(sum==n1){
            System.out.println("input number is perfect number");
        }
        else{
            System.out.println("input number is not perfect number");
        }
        sc.close();
    }
}
