import java.util.Scanner;
class ConvertDecimalToBinary {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any decimal number");
        int n=sc.nextInt();
        String bin="";
        int r;
        while (n>0) {
            r=n%2;
            bin=r+bin;
            n=n/2;
        }
        System.out.println(bin);
        sc.close();
    }
    
}
