import java.util.Scanner;
class CheckStrongNumber {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int n1=n,sum=0;
        while (n>0) {
            int r=n%10;
            int f=1;
            while (r>1) {
                f=f*r;
                r--;
            }
            sum=sum+f;   
            n=n/10;
        }
        if(sum==n1){
            System.out.println("input number is strong number");
        }
        else{
            System.out.println("input number is not strong number ");
        }
        sc.close();
    }
}
