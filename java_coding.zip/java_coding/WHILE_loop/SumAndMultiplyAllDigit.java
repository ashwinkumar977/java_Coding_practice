import java.util.Scanner;
/**
 * SumAndMultiplyAllDigit
 */
public class SumAndMultiplyAllDigit {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int s=0,m=1,r;
        while (n>0) {
            r=n%10;
            s=s+r;
            m=m*r;
            n=n/10;
        }
        System.out.println("sum of all digit of input number="+s);
        System.out.println("multiplycation of all digit of input number="+m);
        sc.close();
    }
}