import java.util.Scanner;
class ConvertDecimalToOctal {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any decimal number");
        int n=sc.nextInt();
        String oct="";
        int r;
        while (n>0) {
            r=n%8;
            oct=r+oct;
            n=n/8;
        }
        System.out.println(oct);
        sc.close();
    }
    
}
