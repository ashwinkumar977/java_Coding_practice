import java.util.Scanner;
import java.lang.Math;
class CheckArmstrong {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int n1=n,i=0;
        while (n>0) {
            n=n/10;
            i++;
        }
        n=n1;
        n1=n;
        int ar=0;
        while(n>0){
            int r=n%10;
            ar=ar+(int)Math.pow(r, i);
            n=n/10;
        }
        System.out.println(ar);
        if(ar == n1){
            System.out.println("input nuber is armstrong number");
        }
        else{
            System.out.println("input number is not armstrong number");
        }
        sc.close();
    }
    
}