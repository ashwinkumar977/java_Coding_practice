/*
 * to check input number is twin prime number or not
 */
import java.util.Scanner;
public class CheckTwinPrimeNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter  first number");
        int n1=sc.nextInt();
        System.out.println("enter second number");
        int n2=sc.nextInt();
        int x=n1,y=n2;
        int i=2,flag1=1;
        while(i<=n1/2){
            if(n1%i==0){
                flag1=0;
            }
            i++;
        }
        int j=2,flag2=1;
        while (j<=n2/2) {
            if(n2%j==0){
                flag2=0;
            }
            j++;
        }
        int flag=0;
        if(flag1==1 && flag2==1){
            if(x+2==y||y+2==x){
                flag=1;
            }
        }
        if(flag==1){
            System.out.println("input both number is twin prime number");
        }
        else{
            System.out.println("input both number is not twin prime number");
        }
        sc.close();
    }
}
