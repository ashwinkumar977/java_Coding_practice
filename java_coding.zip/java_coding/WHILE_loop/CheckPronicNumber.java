/*
 * to check input number is pronic number or not
 */
import java.util.Scanner;
public class CheckPronicNumber {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        

        sc.close();
    }
}
