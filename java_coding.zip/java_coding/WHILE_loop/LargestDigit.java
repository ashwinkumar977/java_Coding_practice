import java.util.*;
class LargestDigit {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int l=0;
        while(n>0){
            int r=n%10;
            if(l<r){
                l=r;
            }
            n=n/10;
        }
        System.out.println("largest digit="+l);
        sc.close();
    } 
}
