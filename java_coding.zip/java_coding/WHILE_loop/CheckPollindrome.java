/** 
 *to check input number is pollindrome number or not 
 */
import java.util.Scanner;
class CheckPollindrome {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter any number");
        int n=sc.nextInt();
        int r,n1=n,rv=0;
        while (n>0) {
            r=n%10;
            rv=rv*10+r;
            n=n/10;
        }
        if(rv==n1){
            System.out.println("input nuber is pollindrome number");
        }
        else{
            System.out.println("input number is not pollindrome number");
        }
        sc.close();
    }
    
}
