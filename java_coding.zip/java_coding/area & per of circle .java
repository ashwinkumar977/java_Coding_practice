import java.util.Scanner;
class Circle
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        float r;  double ar,p;
        System.out.println("enter radius of circle");
        r=sc.nextFloat();
        ar=3.14*r*r;
        p=2*3.14*r;
        System.out.print(ar+"\t"+p);
        sc.close();
    }
}
