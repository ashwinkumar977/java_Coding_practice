//to calculate diagonal of rectangle
import java.util.Scanner;
class DiagonalRectangle
{
    public static void main(String arr[])
    {
        Scanner sc=new Scanner (System.in);
        System.out.println("enter length and breadth of rectangle");
        double l=sc.nextDouble();
        double b=sc.nextDouble();
        double d=Math.sqrt(l*l+b*b);
        System.out.println("diagonal of rectangle="+d);
    }
}