//to sum of two number without using '-' operator
import java.util.Scanner;
class SubtractWithoutMinusOperator
{
   public static void main(String arr[])
   {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter any two number");
       int a=sc.nextInt();
       int b=sc.nextInt();
       int substract=a+(~b+1);
       System.out.println("substrct of two number="+substract);
       sc.close();
   }
}